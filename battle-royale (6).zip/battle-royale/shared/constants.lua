-- Shared helpers. IsDuplicityVersion() is true on the server, so client-only
-- natives are never referenced there.

BR_IS_SERVER = IsDuplicityVersion()

-- ================================ LOCALE ==================================

function BRLocale(key, ...)
    local pack = Config.Languages[Config.Locale] or Config.Languages.EN
    local str = pack[key] or (Config.Languages.EN and Config.Languages.EN[key]) or key
    if select('#', ...) > 0 then
        local ok, formatted = pcall(string.format, str, ...)
        if ok then return formatted end
    end
    return str
end

function BRDebug(...)
    if not Config.Debug then return end
    local parts = {}
    for i = 1, select('#', ...) do
        parts[#parts + 1] = tostring(select(i, ...))
    end
    print(('[battle-royale] %s'):format(table.concat(parts, ' ')))
end

-- ================================ LOOKUPS =================================

-- Config.LootCrates is an ARRAY; indexing it with a string id yields nil.
function BRGetCrateById(crateId)
    for _, crate in ipairs(Config.LootCrates) do
        if crate.id == crateId then return crate end
    end
    return nil
end

-- Searches every shop category, not just one.
function BRFindShopItem(id)
    for _, category in ipairs(Config.ShopOrder) do
        for _, item in ipairs(Config.ShopItems[category] or {}) do
            if item.id == id then return item, category end
        end
    end
    return nil
end

function BRGetSkinForWeapon(skinIds, weaponName)
    if not skinIds then return nil end
    for _, id in ipairs(skinIds) do
        local item = BRFindShopItem(id)
        if item and item.weapon == weaponName then return item end
    end
    return nil
end

function BRGetMinPlayers(mode)
    local modeData = Config.GameModes[mode]
    if not modeData then return nil end
    if Config.Debug then
        return math.min(modeData.minPlayers, Config.DebugMinPlayers)
    end
    return modeData.minPlayers
end

-- =============================== UTILITIES ================================

function BRClamp(value, minValue, maxValue)
    value = tonumber(value)
    if not value then return minValue end
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

function BRRound(value, decimals)
    local mult = 10 ^ (decimals or 0)
    return math.floor(tonumber(value or 0) * mult + 0.5) / mult
end

function BRLevelFromXp(xp)
    xp = tonumber(xp) or 0
    local per = Config.Rewards.xpPerLevel
    local level, remaining = 1, xp
    while remaining >= level * per do
        remaining = remaining - (level * per)
        level = level + 1
        if level > 999 then break end
    end
    return level, remaining, level * per
end

-- Rolls a loot tier using the configured weights.
function BRRollTier()
    local total = 0
    for _, tier in ipairs(Config.TierOrder) do
        total = total + (Config.LootTiers[tier].weight or 0)
    end
    if total <= 0 then return Config.TierOrder[1] end

    local roll = math.random() * total
    local acc = 0
    for _, tier in ipairs(Config.TierOrder) do
        acc = acc + (Config.LootTiers[tier].weight or 0)
        if roll <= acc then return tier end
    end
    return Config.TierOrder[#Config.TierOrder]
end

-- Strips control characters, NUI-breaking markup and trims length. Applied to
-- every chat message on the SERVER, so a crafted client cannot inject HTML.
function BRSanitiseText(text, maxLength)
    if type(text) ~= 'string' then return nil end
    text = text:gsub('[%c]', ' ')
    text = text:gsub('[<>]', '')
    text = text:gsub('^%s+', ''):gsub('%s+$', '')
    text = text:gsub('%s%s+', ' ')
    if text == '' then return nil end
    if maxLength and #text > maxLength then
        text = text:sub(1, maxLength)
    end
    return text
end

-- ============================== CLIENT ONLY ===============================

if not BR_IS_SERVER then
    function LoadModel(model)
        local hash = type(model) == 'string' and joaat(model) or model
        if not IsModelValid(hash) then return false end
        RequestModel(hash)
        local timeout = 0
        while not HasModelLoaded(hash) do
            Wait(10)
            timeout = timeout + 10
            if timeout > 8000 then return false end
        end
        return true, hash
    end

    function DrawText3D(coords, text)
        local onScreen, x, y = GetScreenCoordFromWorldCoord(coords.x, coords.y, coords.z)
        if not onScreen then return end
        SetTextScale(0.34, 0.34)
        SetTextFont(4)
        SetTextProportional(true)
        SetTextColour(255, 255, 255, 215)
        SetTextCentre(true)
        SetTextEntry('STRING')
        AddTextComponentSubstringPlayerName(text)
        EndTextCommandDisplayText(x, y)
        local factor = #text / 370
        DrawRect(x, y + 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 90)
    end

    function BRFormatTime(seconds)
        seconds = math.max(0, math.floor(tonumber(seconds) or 0))
        return ('%02d:%02d'):format(math.floor(seconds / 60), seconds % 60)
    end
end
