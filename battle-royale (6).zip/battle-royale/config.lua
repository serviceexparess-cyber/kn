Config = {}

-- Debug lowers the player requirement so a match can be started alone.
Config.Debug = true
Config.DebugMinPlayers = 1

Config.Command = 'br'
Config.AltCommand = 'battleroyale'
Config.Locale = 'FR'          -- 'EN' or 'FR'

-- =============================== GAME MODES ===============================

Config.ModeOrder = { 'Solo', 'Duo', 'Trio', 'Squad' }

Config.GameModes = {
    Solo  = { label = 'SOLO',  teamSize = 1, minPlayers = 2,  maxPlayers = 100 },
    Duo   = { label = 'DUO',   teamSize = 2, minPlayers = 4,  maxPlayers = 100 },
    Trio  = { label = 'TRIO',  teamSize = 3, minPlayers = 6,  maxPlayers = 90  },
    Squad = { label = 'SQUAD', teamSize = 4, minPlayers = 8,  maxPlayers = 100 }
}

-- ================================= ROOMS ==================================

Config.Rooms = {
    codeLength = 5,
    maxRooms = 25,
    -- Room settings a host is allowed to change, with hard server-side bounds.
    -- Never trust the values the UI sends; everything is clamped to these.
    limits = {
        maxPlayers  = { min = 2,   max = 100, default = 30 },
        shrinkSpeed = { min = 0.5, max = 3.0, default = 1.0 },  -- multiplier
        gasDamage   = { min = 1,   max = 25,  default = 5 }
    },
    defaults = {
        planeDrop    = true,
        dropsEnabled = true,
        friendlyFire = false
    },
    chat = {
        maxLength = 120,
        history = 40,
        cooldown = 1          -- seconds between messages
    },
    -- Auto-start countdown once minPlayers is reached (seconds).
    autoStartCountdown = 20
}

-- ================================== MAP ===================================

-- Several maps are defined; Config.ActiveMap picks which one is currently
-- played. Switching maps is just changing that one line.
Config.Maps = {
    gta5 = {
        name = 'gta5',
        center = vector3(0.0, 0.0, 72.0),
        initialRadius = 1400.0,
        spawnPoints = {
            vector3(-100.0, 100.0, 71.0),
            vector3(200.0, -150.0, 50.0),
            vector3(-420.0, 1180.0, 325.0),
            vector3(1200.0, -650.0, 65.0),
            vector3(-800.0, -200.0, 37.0),
            vector3(450.0, 600.0, 180.0),
            vector3(900.0, 200.0, 80.0),
            vector3(-1200.0, 400.0, 75.0)
        }
    },
    -- Cayo Perico: needs the server's game build high enough to stream the
    -- island (sv_enforceGameBuild 2802 or higher in server.cfg). Coordinates
    -- below are approximate - nudge them in-game if a spawn lands in water
    -- or inside a rock.
    cayo_perico = {
        name = 'cayo_perico',
        center = vector3(4890.0, -5190.0, 3.0),
        initialRadius = 900.0,
        spawnPoints = {
            vector3(4931.5, -5170.0, 2.0),  -- compound
            vector3(5222.7, -4635.7, 2.7),  -- north airstrip
            vector3(4600.0, -5320.0, 2.0),  -- docks
            vector3(4830.0, -4979.0, 32.0), -- west village / hills
            vector3(4650.0, -5350.0, 2.0),  -- south beach
            vector3(5100.0, -4900.0, 2.0),  -- north-east coast
            vector3(4750.0, -5100.0, 15.0), -- jungle interior
            vector3(4980.0, -5290.0, 2.0)   -- restricted area coast
        }
    }
}

Config.ActiveMap = 'cayo_perico'
Config.Map = Config.Maps[Config.ActiveMap]
Config.SpawnPoints = Config.Map.spawnPoints

-- ============================== PLANE DROP ================================

Config.PlaneDrop = {
    enabled = true,
    model = 'titan',
    altitude = 400.0,
    speed = 90.0,             -- m/s along the flight path
    -- The plane crosses the map through the centre; the bearing is randomised
    -- per match so the flight line is never the same.
    pathLength = 3000.0,
    -- Seconds after boarding before the player is forced out.
    forcedJumpAfter = 40,
    parachute = 'GADGET_PARACHUTE',
    -- Altitude under which the parachute auto-deploys as a safety net.
    autoDeployHeight = 120.0
}

-- ============================ DYNAMIC GAS ZONE ============================

-- Phases run in order. Each phase waits, then shrinks to `radius` over
-- `shrink` seconds while the centre drifts inward. Damage ramps up per phase.
Config.ZonePhases = {
    { wait = 60, shrink = 90, radius = 1000.0, damage = 2  },
    { wait = 45, shrink = 75, radius = 700.0,  damage = 3  },
    { wait = 40, shrink = 60, radius = 450.0,  damage = 5  },
    { wait = 35, shrink = 50, radius = 250.0,  damage = 8  },
    { wait = 30, shrink = 40, radius = 120.0,  damage = 12 },
    { wait = 25, shrink = 30, radius = 40.0,   damage = 18 },
    { wait = 20, shrink = 25, radius = 0.0,    damage = 25 }
}

Config.Zone = {
    tickRate = 1000,          -- ms between zone broadcasts
    -- How far the centre may drift inward each phase, as a fraction of the
    -- radius lost. 0 = never moves, 1 = may sit against the new edge.
    driftFactor = 0.6,
    -- Visuals
    blipAlpha = 128,
    warnBeforeShrink = 10     -- seconds of on-screen warning
}

-- ================================= LOOT ===================================

-- Weapons are real: the loot handler calls GiveWeaponToPed with these hashes.
Config.LootTiers = {
    Common = {
        weight = 55,
        weapons = { 'WEAPON_PISTOL', 'WEAPON_SNSPISTOL' },
        items   = { { type = 'armor', value = 25 }, { type = 'health', value = 25 } },
        ammo = 60
    },
    Rare = {
        weight = 27,
        weapons = { 'WEAPON_MICROSMG', 'WEAPON_PUMPSHOTGUN' },
        items   = { { type = 'armor', value = 50 }, { type = 'health', value = 50 } },
        ammo = 120
    },
    Epic = {
        weight = 13,
        weapons = { 'WEAPON_CARBINERIFLE', 'WEAPON_ASSAULTRIFLE' },
        items   = { { type = 'armor', value = 75 } },
        ammo = 180
    },
    Legendary = {
        weight = 5,
        weapons = { 'WEAPON_SNIPERRIFLE', 'WEAPON_SPECIALCARBINE' },
        items   = { { type = 'armor', value = 100 }, { type = 'health', value = 100 } },
        ammo = 120
    }
}
Config.TierOrder = { 'Common', 'Rare', 'Epic', 'Legendary' }

-- Crate positions. Tier is rolled per match from the weights above, so the same
-- crate is not always the same reward.
-- Coordinates below are on Cayo Perico (Config.ActiveMap): the original GTA5
-- mainland crate spots would all land in open ocean on this map. Re-run this
-- through the mainland list (kept in git history / the previous config) if
-- you switch Config.ActiveMap back to 'gta5'.
Config.LootCrates = {
    { id = 'c1',  coords = vector3(4931.5, -5170.0, 2.0)  }, -- compound
    { id = 'c2',  coords = vector3(5222.7, -4635.7, 3.0)  }, -- north airstrip
    { id = 'c3',  coords = vector3(4600.0, -5320.0, 2.0)  }, -- docks
    { id = 'c4',  coords = vector3(4830.0, -4979.0, 33.0) }, -- west village / hills
    { id = 'c5',  coords = vector3(4670.0, -5360.0, 2.0)  }, -- south beach
    { id = 'c6',  coords = vector3(5100.0, -4900.0, 2.0)  }, -- north-east coast
    { id = 'c7',  coords = vector3(4750.0, -5100.0, 15.0) }, -- jungle interior
    { id = 'c8',  coords = vector3(4980.0, -5290.0, 2.0)  }, -- restricted area coast
    { id = 'c9',  coords = vector3(4890.0, -5030.0, 40.0) }, -- central hills
    { id = 'c10', coords = vector3(5000.0, -5230.0, 5.0)  }  -- mid-island
}

Config.CrateModel = 'prop_box_ammo04a'

-- ============================ SHOP / LOADOUT ==============================

Config.Currencies = { Gold = 'gold', Diamonds = 'diamonds' }

-- Weapon skins are real tints/components applied on spawn.
-- `weapon` must match a weapon that appears in Config.LootTiers.
-- `tint` is the GTA weapon tint index (0-7).
Config.ShopItems = {
    Crates = {
        { id = 'crate_basic',  name = 'Basic Crate',     price = 1000, currency = 'Gold',     rarity = 'Common'    },
        { id = 'crate_adv',    name = 'Advanced Crate',  price = 5000, currency = 'Gold',     rarity = 'Rare'      },
        { id = 'crate_legend', name = 'Legendary Crate', price = 100,  currency = 'Diamonds', rarity = 'Legendary' }
    },
    WeaponSkins = {
        { id = 'skin_ak_red',   name = 'AK-47 | Red Dragon',  price = 50,   currency = 'Diamonds', rarity = 'Legendary', weapon = 'WEAPON_ASSAULTRIFLE',  tint = 1 },
        { id = 'skin_m4_neon',  name = 'M4 | Neon Pulse',     price = 5000, currency = 'Gold',     rarity = 'Epic',      weapon = 'WEAPON_CARBINERIFLE',  tint = 5 },
        { id = 'skin_snp_gold', name = 'Sniper | Golden Eye', price = 75,   currency = 'Diamonds', rarity = 'Legendary', weapon = 'WEAPON_SNIPERRIFLE',   tint = 2 },
        { id = 'skin_smg_blue', name = 'SMG | Cyber Blue',    price = 2000, currency = 'Gold',     rarity = 'Rare',      weapon = 'WEAPON_MICROSMG',      tint = 4 },
        { id = 'skin_pst_army', name = 'Pistol | Army Green', price = 800,  currency = 'Gold',     rarity = 'Common',    weapon = 'WEAPON_PISTOL',        tint = 3 }
    },
    PlayerTags = {
        { id = 'tag_mvp',     name = 'MVP',         price = 10, currency = 'Diamonds', rarity = 'Epic'   },
        { id = 'tag_sniper',  name = 'Sniper King', price = 8,  currency = 'Diamonds', rarity = 'Rare'   },
        { id = 'tag_warrior', name = 'Warrior',     price = 5,  currency = 'Gold',     rarity = 'Common' }
    }
}
Config.ShopOrder = { 'Crates', 'WeaponSkins', 'PlayerTags' }

-- Reward granted at the end of a match.
Config.Rewards = {
    perKill      = { gold = 50,  xp = 25 },
    win          = { gold = 500, xp = 250, diamonds = 1 },
    participation = { gold = 25,  xp = 10 },
    -- XP needed for level N is level * xpPerLevel.
    xpPerLevel = 1000
}

Config.Leaderboard = { limit = 15 }

-- ================================ LOCALES =================================

Config.Languages = {
    EN = {
        welcome            = 'Welcome to Battle Royale!',
        room_created       = 'Room %s created.',
        room_joined        = 'You joined room %s.',
        room_left          = 'You left the room.',
        room_not_found     = 'Room not found.',
        room_full          = 'That room is full.',
        room_in_progress   = 'That match has already started.',
        room_host_only     = 'Only the host can do that.',
        room_need_players  = 'Not enough players (%s required).',
        already_in_room    = 'You are already in a room.',
        not_in_room        = 'You are not in a room.',
        match_starting     = 'Match starting in %s...',
        in_game            = 'You cannot do that during a match.',
        insufficient_funds = 'Insufficient funds.',
        purchase_ok        = 'Purchase successful.',
        already_owned      = 'You already own that.',
        skin_equipped      = 'Skin equipped.',
        looted_weapon      = 'Looted: %s',
        looted_armor       = 'Armor +%s',
        looted_health      = 'Health +%s',
        crate_empty        = 'This crate is empty.',
        zone_warning       = 'The gas closes in %s seconds!',
        outside_zone       = 'You are in the gas!',
        eliminated         = 'Eliminated! Placed #%s',
        victory            = 'Victory Royale! You placed #1',
        killed             = 'You eliminated %s',
        jump_prompt        = 'Press ~INPUT_JUMP~ to jump',
        chat_too_fast      = 'Slow down.'
    },
    FR = {
        welcome            = 'Bienvenue dans Battle Royale !',
        room_created       = 'Salle %s creee.',
        room_joined        = 'Vous avez rejoint la salle %s.',
        room_left          = 'Vous avez quitte la salle.',
        room_not_found     = 'Salle introuvable.',
        room_full          = 'Cette salle est pleine.',
        room_in_progress   = 'Cette partie a deja commence.',
        room_host_only     = "Seul l'hote peut faire cela.",
        room_need_players  = 'Pas assez de joueurs (%s requis).',
        already_in_room    = 'Vous etes deja dans une salle.',
        not_in_room        = "Vous n'etes dans aucune salle.",
        match_starting     = 'Partie dans %s...',
        in_game            = 'Impossible pendant une partie.',
        insufficient_funds = 'Fonds insuffisants.',
        purchase_ok        = 'Achat reussi.',
        already_owned      = 'Vous possedez deja cet objet.',
        skin_equipped      = 'Skin equipe.',
        looted_weapon      = 'Recupere : %s',
        looted_armor       = 'Armure +%s',
        looted_health      = 'Vie +%s',
        crate_empty        = 'Cette caisse est vide.',
        zone_warning       = 'Le gaz se resserre dans %s secondes !',
        outside_zone       = 'Vous etes dans le gaz !',
        eliminated         = 'Elimine ! Place #%s',
        victory            = 'Victoire Royale ! Vous finissez #1',
        killed             = 'Vous avez elimine %s',
        jump_prompt        = 'Appuyez sur ~INPUT_JUMP~ pour sauter',
        chat_too_fast      = 'Trop rapide.'
    }
}
