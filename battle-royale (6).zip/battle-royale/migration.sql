-- ==========================================================================
-- Battle Royale v3 - REPARATION D'UNE BASE EXISTANTE
-- ==========================================================================
-- A utiliser si vous avez l'erreur :
--   Unknown column 'equipped' in 'field list'
-- ...ou toute autre "Unknown column" sur une table br_*.
--
-- Cela veut dire qu'une table br_* d'une ancienne version existe deja, sans
-- les colonnes de la v3. Ce script les ajoute sans toucher aux donnees.
--
-- Deux facons de le lancer :
--   mysql -u root -p votre_base < migration.sql
--   ...ou copier-coller le bloc ci-dessous dans phpMyAdmin / HeidiSQL.
--
-- Il est sans danger a relancer : chaque colonne n'est ajoutee que si elle
-- manque.
-- ==========================================================================

DROP PROCEDURE IF EXISTS br_add_column;

DELIMITER $$
CREATE PROCEDURE br_add_column(
    IN p_table VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_ddl TEXT
)
BEGIN
    -- On ne fait rien si la table n'existe pas encore : database.sql la creera.
    IF EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table
    ) AND NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND COLUMN_NAME = p_column
    ) THEN
        SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_ddl);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

-- ------------------------------- br_players -------------------------------
CALL br_add_column('br_players', 'name',       'VARCHAR(64) DEFAULT NULL');
CALL br_add_column('br_players', 'xp',         'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'level',      'INT NOT NULL DEFAULT 1');
CALL br_add_column('br_players', 'kills',      'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'deaths',     'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'wins',       'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'matches',    'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'gold',       'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'diamonds',   'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_players', 'created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');

-- ------------------------------ br_inventory ------------------------------
-- C'est celle-ci qui provoque l'erreur "Unknown column 'equipped'".
CALL br_add_column('br_inventory', 'item_id',     "VARCHAR(64) NOT NULL DEFAULT ''");
CALL br_add_column('br_inventory', 'item_type',   "VARCHAR(32) NOT NULL DEFAULT 'Unknown'");
CALL br_add_column('br_inventory', 'equipped',    'TINYINT(1) NOT NULL DEFAULT 0');
CALL br_add_column('br_inventory', 'acquired_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');

-- ---------------------------- br_match_history ----------------------------
CALL br_add_column('br_match_history', 'mode',             "VARCHAR(16) NOT NULL DEFAULT 'Solo'");
CALL br_add_column('br_match_history', 'placement',        'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'total_players',    'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'kills',            'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'damage',           'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'survived_seconds', 'INT NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'won',              'TINYINT(1) NOT NULL DEFAULT 0');
CALL br_add_column('br_match_history', 'played_at',        'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');

DROP PROCEDURE IF EXISTS br_add_column;

-- Verification : les 3 lignes doivent afficher les colonnes attendues.
SELECT TABLE_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY ORDINAL_POSITION) AS colonnes
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('br_players', 'br_inventory', 'br_match_history')
GROUP BY TABLE_NAME;
