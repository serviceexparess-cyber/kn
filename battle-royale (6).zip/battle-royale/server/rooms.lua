-- Custom rooms: public/private lobbies with host-controlled rules and chat.

local function clampSettings(input)
    local limits = Config.Rooms.limits
    local defaults = Config.Rooms.defaults
    input = type(input) == 'table' and input or {}

    -- Every value is clamped server-side. The UI is never trusted.
    return {
        maxPlayers = math.floor(BRClamp(input.maxPlayers or limits.maxPlayers.default,
            limits.maxPlayers.min, limits.maxPlayers.max)),
        shrinkSpeed = BRRound(BRClamp(input.shrinkSpeed or limits.shrinkSpeed.default,
            limits.shrinkSpeed.min, limits.shrinkSpeed.max), 2),
        gasDamage = math.floor(BRClamp(input.gasDamage or limits.gasDamage.default,
            limits.gasDamage.min, limits.gasDamage.max)),
        planeDrop = input.planeDrop ~= nil and (input.planeDrop and true or false) or defaults.planeDrop,
        dropsEnabled = input.dropsEnabled ~= nil and (input.dropsEnabled and true or false) or defaults.dropsEnabled,
        friendlyFire = input.friendlyFire ~= nil and (input.friendlyFire and true or false) or defaults.friendlyFire
    }
end

function CountRoomPlayers(room)
    return room and #room.order or 0
end

function BuildRoomPayload(room)
    if not room then return nil end
    local players = {}
    for _, src in ipairs(room.order) do
        local entry = room.players[src]
        if entry then
            players[#players + 1] = {
                id = src,
                name = entry.name,
                level = entry.level or 1,
                ready = entry.ready and true or false,
                isHost = src == room.host
            }
        end
    end
    return {
        code = room.code,
        mode = room.mode,
        visibility = room.visibility,
        host = room.host,
        state = room.state,
        settings = room.settings,
        players = players,
        count = #players,
        minPlayers = BRGetMinPlayers(room.mode),
        chat = room.chat,
        countdown = room.countdown
    }
end

function BuildRoomList()
    local list = {}
    for _, room in pairs(Rooms) do
        if room.visibility == 'public' and room.state == 'lobby' then
            list[#list + 1] = {
                code = room.code,
                mode = room.mode,
                count = CountRoomPlayers(room),
                maxPlayers = room.settings.maxPlayers,
                hostName = room.players[room.host] and room.players[room.host].name or '?',
                planeDrop = room.settings.planeDrop
            }
        end
    end
    table.sort(list, function(a, b) return a.count > b.count end)
    return list
end

-- Pushes the room state to every member, and the public list to everyone in the
-- menu, so no client can hold a stale view.
function SyncRoom(room)
    if not room then return end
    local payload = BuildRoomPayload(room)
    for _, src in ipairs(room.order) do
        -- `you` is set per recipient so each client knows which row is itself,
        -- and therefore whether it is the host, without guessing.
        payload.you = src
        TriggerClientEvent('br:client:roomUpdate', src, payload)
    end
end

function BroadcastRoomList()
    local list = BuildRoomList()
    for src in pairs(BRPlayers) do
        if not PlayerGame[src] then
            TriggerClientEvent('br:client:roomList', src, list)
        end
    end
end

-- =============================== LIFECYCLE ================================

local function addPlayerToRoom(room, src)
    local stats = GetPlayerStats(src) or {}
    room.players[src] = {
        name = GetDisplayName(src),
        level = BRLevelFromXp(stats.xp or 0),
        ready = false
    }
    room.order[#room.order + 1] = src
    PlayerRoom[src] = room.code
end

function CreateRoom(src, mode, visibility, settings)
    if CountRooms() >= Config.Rooms.maxRooms then
        Notify(src, 'Too many rooms open, try again later.')
        return nil
    end

    local code = GenerateRoomCode()
    if not code then
        Notify(src, 'Could not allocate a room code.')
        return nil
    end

    local room = {
        code = code,
        host = src,
        mode = mode,
        visibility = visibility == 'private' and 'private' or 'public',
        settings = clampSettings(settings),
        players = {},
        order = {},
        chat = {},
        state = 'lobby',
        countdown = nil,
        createdAt = os.time()
    }
    Rooms[code] = room
    addPlayerToRoom(room, src)

    Notify(src, BRLocale('room_created', code))
    SyncRoom(room)
    BroadcastRoomList()
    BRDebug('room created', code, mode, visibility)
    return room
end

function LeaveRoom(src, silent)
    local code = PlayerRoom[src]
    if not code then return false end
    local room = Rooms[code]
    PlayerRoom[src] = nil
    if not room then return false end

    room.players[src] = nil
    for i = #room.order, 1, -1 do
        if room.order[i] == src then table.remove(room.order, i) end
    end

    if not silent then
        TriggerClientEvent('br:client:roomLeft', src)
        Notify(src, BRLocale('room_left'))
    end

    if #room.order == 0 then
        -- Last member out: destroy the room rather than leaving a ghost entry
        -- in the public list.
        Rooms[code] = nil
        BRDebug('room destroyed (empty)', code)
    else
        if room.host == src then
            room.host = room.order[1]
            AddSystemChat(room, ('%s is now the host.'):format(room.players[room.host].name))
        end
        -- Losing a player can invalidate a running countdown.
        if room.countdown and #room.order < (BRGetMinPlayers(room.mode) or 2) then
            room.countdown = nil
            AddSystemChat(room, 'Countdown cancelled: not enough players.')
        end
        SyncRoom(room)
    end

    BroadcastRoomList()
    return true
end

-- ================================= EVENTS =================================

RegisterNetEvent('br:server:createRoom', function(data)
    local src = source
    -- Never fail silently here: an unanswered click is impossible to debug.
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'createRoom', 3) then
        Notify(src, 'Slow down - wait a moment before creating another room.')
        return
    end
    if PlayerGame[src] then Notify(src, BRLocale('in_game')) return end
    if PlayerRoom[src] then Notify(src, BRLocale('already_in_room')) return end

    data = type(data) == 'table' and data or {}
    local mode = data.mode
    if type(mode) ~= 'string' or mode == '' then
        Notify(src, 'Pick a mode first.')
        return
    end
    if not Config.GameModes[mode] then
        Notify(src, ('Unknown mode "%s".'):format(tostring(mode)))
        print(('[battle-royale] createRoom refused: unknown mode %q from src %d')
            :format(tostring(mode), src))
        return
    end

    CreateRoom(src, mode, data.visibility, data.settings)
end)

-- Shared by the manual "enter a code" join and by accepting an invite, so
-- both paths get exactly the same validation.
function JoinRoomByCode(src, code)
    if PlayerGame[src] then Notify(src, BRLocale('in_game')) return end
    if PlayerRoom[src] then Notify(src, BRLocale('already_in_room')) return end
    if type(code) ~= 'string' then return end

    code = code:upper():gsub('[^A-Z0-9]', '')
    local room = Rooms[code]
    if not room then Notify(src, BRLocale('room_not_found')) return end
    if room.state ~= 'lobby' then Notify(src, BRLocale('room_in_progress')) return end
    if CountRoomPlayers(room) >= room.settings.maxPlayers then
        Notify(src, BRLocale('room_full'))
        return
    end

    addPlayerToRoom(room, src)
    Notify(src, BRLocale('room_joined', code))
    AddSystemChat(room, ('%s joined.'):format(room.players[src].name))
    SyncRoom(room)
    BroadcastRoomList()
    MaybeStartCountdown(room)
end

RegisterNetEvent('br:server:joinRoom', function(code)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'joinRoom', 1) then return end
    JoinRoomByCode(src, code)
end)

-- ================================ INVITES ==================================
-- Lets a room member pull a specific player straight back into their party by
-- server id, instead of that player having to be told the code out of band.

RegisterNetEvent('br:server:invitePlayer', function(targetId)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'invite', 1) then return end

    local code = PlayerRoom[src]
    local room = code and Rooms[code]
    if not room then Notify(src, BRLocale('not_in_room')) return end
    if room.state ~= 'lobby' then Notify(src, BRLocale('room_in_progress')) return end

    targetId = tonumber(targetId)
    if not targetId or not GetPlayerName(targetId) then
        Notify(src, 'Joueur introuvable (verifie l\'ID).')
        return
    end
    if targetId == src then
        Notify(src, 'Tu ne peux pas t\'inviter toi-meme.')
        return
    end
    if PlayerGame[targetId] then Notify(src, 'Ce joueur est deja en partie.') return end
    if PlayerRoom[targetId] then Notify(src, 'Ce joueur est deja dans un salon.') return end
    if CountRoomPlayers(room) >= room.settings.maxPlayers then
        Notify(src, BRLocale('room_full'))
        return
    end

    PendingInvites[targetId] = { code = room.code, from = src, expires = os.time() + 60 }

    local inviterName = room.players[src] and room.players[src].name or GetPlayerName(src)
    Notify(src, ('Invitation envoyee a %s (code %s).'):format(GetPlayerName(targetId), room.code))
    Notify(targetId, ('%s t\'invite dans son salon (code %s). Tape /brjoin pour accepter.')
        :format(inviterName, room.code))
    TriggerClientEvent('br:client:roomInvite', targetId, { code = room.code, fromName = inviterName })
end)

RegisterNetEvent('br:server:acceptInvite', function()
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'joinRoom', 1) then return end

    local invite = PendingInvites[src]
    if not invite or invite.expires < os.time() then
        PendingInvites[src] = nil
        Notify(src, 'Aucune invitation en attente (ou elle a expire).')
        return
    end
    PendingInvites[src] = nil
    JoinRoomByCode(src, invite.code)
end)

RegisterNetEvent('br:server:leaveRoom', function()
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'leaveRoom', 0.5) then return end
    if not LeaveRoom(src) then Notify(src, BRLocale('not_in_room')) end
end)

-- Quick match: join the fullest public room for that mode, or open one.
RegisterNetEvent('br:server:quickMatch', function(mode)
    local src = source
    -- Same rule as createRoom: always answer, never return in silence.
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'quickMatch', 2) then
        Notify(src, 'Slow down - wait a moment.')
        return
    end
    if PlayerGame[src] then Notify(src, BRLocale('in_game')) return end
    if PlayerRoom[src] then Notify(src, BRLocale('already_in_room')) return end
    if type(mode) ~= 'string' or mode == '' or not Config.GameModes[mode] then
        Notify(src, ('Unknown mode "%s".'):format(tostring(mode)))
        return
    end

    local best
    for _, room in pairs(Rooms) do
        if room.visibility == 'public' and room.state == 'lobby' and room.mode == mode
            and CountRoomPlayers(room) < room.settings.maxPlayers then
            if not best or CountRoomPlayers(room) > CountRoomPlayers(best) then
                best = room
            end
        end
    end

    if best then
        addPlayerToRoom(best, src)
        Notify(src, BRLocale('room_joined', best.code))
        AddSystemChat(best, ('%s joined.'):format(best.players[src].name))
        SyncRoom(best)
        BroadcastRoomList()
        MaybeStartCountdown(best)
    else
        CreateRoom(src, mode, 'public', nil)
    end
end)

RegisterNetEvent('br:server:toggleReady', function()
    local src = source
    local room = Rooms[PlayerRoom[src] or '']
    if not room or room.state ~= 'lobby' then return end
    if OnCooldown(src, 'ready', 0.4) then return end
    local entry = room.players[src]
    if not entry then return end
    entry.ready = not entry.ready
    SyncRoom(room)
    MaybeStartCountdown(room)
end)

RegisterNetEvent('br:server:updateRoomSettings', function(data)
    local src = source
    local room = Rooms[PlayerRoom[src] or '']
    if not room or room.state ~= 'lobby' then return end
    if room.host ~= src then Notify(src, BRLocale('room_host_only')) return end
    if OnCooldown(src, 'settings', 0.4) then return end

    data = type(data) == 'table' and data or {}
    room.settings = clampSettings(data.settings or data)
    if data.visibility == 'public' or data.visibility == 'private' then
        room.visibility = data.visibility
    end
    if type(data.mode) == 'string' and Config.GameModes[data.mode] then
        room.mode = data.mode
    end

    -- Shrinking the cap below the current headcount would leave players in a
    -- room they can no longer be in, so raise it back to the headcount.
    local count = CountRoomPlayers(room)
    if room.settings.maxPlayers < count then
        room.settings.maxPlayers = count
    end

    SyncRoom(room)
    BroadcastRoomList()
end)

RegisterNetEvent('br:server:startRoom', function()
    local src = source
    local room = Rooms[PlayerRoom[src] or '']
    if not room then Notify(src, BRLocale('not_in_room')) return end
    if room.host ~= src then Notify(src, BRLocale('room_host_only')) return end
    if room.state ~= 'lobby' then
        Notify(src, 'The match is already starting.')
        return
    end
    if OnCooldown(src, 'startRoom', 2) then
        Notify(src, 'Slow down - wait a moment.')
        return
    end

    local minPlayers = BRGetMinPlayers(room.mode) or 2
    if CountRoomPlayers(room) < minPlayers then
        Notify(src, BRLocale('room_need_players', minPlayers))
        return
    end
    BeginCountdown(room, 5)
end)

-- ================================ COUNTDOWN ===============================

function MaybeStartCountdown(room)
    if room.state ~= 'lobby' or room.countdown then return end
    local minPlayers = BRGetMinPlayers(room.mode) or 2
    if CountRoomPlayers(room) < minPlayers then return end

    -- Auto-start only when everybody is ready; otherwise the host starts it.
    for _, src in ipairs(room.order) do
        if not room.players[src].ready then return end
    end
    BeginCountdown(room, Config.Rooms.autoStartCountdown)
end

function BeginCountdown(room, seconds)
    if room.countdown then return end
    room.countdown = seconds
    AddSystemChat(room, ('Match starting in %s seconds.'):format(seconds))
    SyncRoom(room)

    CreateThread(function()
        local code = room.code
        while true do
            Wait(1000)
            -- Re-read: the room can be destroyed mid-countdown.
            local current = Rooms[code]
            if not current or current.state ~= 'lobby' or not current.countdown then return end

            current.countdown = current.countdown - 1
            if current.countdown <= 0 then
                current.countdown = nil
                if CountRoomPlayers(current) < (BRGetMinPlayers(current.mode) or 2) then
                    AddSystemChat(current, 'Cancelled: not enough players.')
                    SyncRoom(current)
                    return
                end
                StartMatchFromRoom(current)
                return
            end
            SyncRoom(current)
        end
    end)
end

-- ================================== CHAT ==================================

function AddSystemChat(room, message)
    if not room then return end
    local entry = { system = true, name = 'SYSTEM', message = message, time = os.time() }
    table.insert(room.chat, entry)
    while #room.chat > Config.Rooms.chat.history do
        table.remove(room.chat, 1)
    end
    for _, src in ipairs(room.order) do
        TriggerClientEvent('br:client:chatMessage', src, entry)
    end
end

RegisterNetEvent('br:server:sendChat', function(text)
    local src = source
    local room = Rooms[PlayerRoom[src] or '']
    if not room then return end
    if OnCooldown(src, 'chat', Config.Rooms.chat.cooldown) then
        Notify(src, BRLocale('chat_too_fast'))
        return
    end

    -- Sanitised on the SERVER: a modified client cannot inject markup into
    -- every other player's interface.
    local clean = BRSanitiseText(text, Config.Rooms.chat.maxLength)
    if not clean then return end

    local entry = {
        system = false,
        name = room.players[src] and room.players[src].name or GetDisplayName(src),
        message = clean,
        time = os.time()
    }
    table.insert(room.chat, entry)
    while #room.chat > Config.Rooms.chat.history do
        table.remove(room.chat, 1)
    end

    for _, target in ipairs(room.order) do
        TriggerClientEvent('br:client:chatMessage', target, entry)
    end
end)

RegisterNetEvent('br:server:requestRooms', function()
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'roomList', 1) then return end
    TriggerClientEvent('br:client:roomList', src, BuildRoomList())
end)
