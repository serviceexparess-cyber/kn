-- Crate looting and the shop / loadout.

-- Sentinel read by the integrity check in server/main.lua. This file only
-- registers events, so it needs an explicit marker to prove it loaded.
function BRLootModuleLoaded() return true end

RegisterNetEvent('br:server:lootCrate', function(crateId)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if type(crateId) ~= 'string' then return end

    local gameId = PlayerGame[src]
    if not gameId then return end
    local game = Games[gameId]
    if not game or not game.alive[src] then return end
    if not game.settings.dropsEnabled then return end
    if OnCooldown(src, 'loot', 1.5) then return end

    -- Lookup by id: Config.LootCrates is an array, so indexing it with the id
    -- string would return nil.
    local crate = BRGetCrateById(crateId)
    if not crate then return end

    -- One loot per crate per match.
    game.lootedCrates[crateId] = game.lootedCrates[crateId] or {}
    if game.lootedCrates[crateId][src] then
        Notify(src, BRLocale('crate_empty'))
        return
    end

    -- Server-side distance check: proximity is not taken on trust.
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return end
    local coords = GetEntityCoords(ped)
    if #(coords - crate.coords) > 6.0 then return end

    local tier = game.crateTiers[crateId] or 'Common'
    local tierData = Config.LootTiers[tier]
    if not tierData then return end

    game.lootedCrates[crateId][src] = true

    -- Give one weapon plus, sometimes, a consumable.
    local weapon = tierData.weapons[math.random(#tierData.weapons)]
    local payload = { weapon = weapon, ammo = tierData.ammo or 60, tier = tier }

    if tierData.items and #tierData.items > 0 and math.random() < 0.5 then
        payload.item = tierData.items[math.random(#tierData.items)]
    end

    -- Weapons are granted by the CLIENT native, but the decision is made here.
    TriggerClientEvent('br:client:receiveLoot', src, payload)
end)

-- ================================= SHOP ===================================

RegisterNetEvent('br:server:purchaseItem', function(itemId)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if type(itemId) ~= 'string' then return end
    if OnCooldown(src, 'purchase', 1) then return end

    -- Looks across every category, so skins and tags are buyable too.
    local item, category = BRFindShopItem(itemId)
    if not item then return end

    -- Crates are consumable; everything else is owned once.
    if category ~= 'Crates' and OwnsItem(src, itemId) then
        Notify(src, BRLocale('already_owned'))
        return
    end

    local stats = GetPlayerStats(src)
    if not stats then return end

    local price = item.price
    if item.currency == 'Gold' then
        if (stats.gold or 0) < price then Notify(src, BRLocale('insufficient_funds')) return end
        stats.gold = stats.gold - price
    elseif item.currency == 'Diamonds' then
        if (stats.diamonds or 0) < price then Notify(src, BRLocale('insufficient_funds')) return end
        stats.diamonds = stats.diamonds - price
    else
        return
    end

    UpdatePlayerStats(src, stats)

    if category == 'Crates' then
        -- Opening a crate rolls a random skin the player does not own yet.
        local pool = {}
        for _, skin in ipairs(Config.ShopItems.WeaponSkins or {}) do
            if not OwnsItem(src, skin.id) then pool[#pool + 1] = skin end
        end
        if #pool > 0 then
            local won = pool[math.random(#pool)]
            AddItem(src, won.id, 'WeaponSkins')
            Notify(src, ('Crate opened: %s'):format(won.name))
        else
            -- Nothing left to win: refund rather than silently take the money.
            if item.currency == 'Gold' then stats.gold = stats.gold + price
            else stats.diamonds = stats.diamonds + price end
            UpdatePlayerStats(src, stats)
            Notify(src, 'You already own every skin - purchase refunded.')
        end
    else
        AddItem(src, itemId, category)
        Notify(src, BRLocale('purchase_ok'))
    end

    SyncStats(src, stats)
    TriggerClientEvent('br:client:updateOwned', src, GetOwnedItems(src))
end)

RegisterNetEvent('br:server:equipSkin', function(itemId, equipped)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if type(itemId) ~= 'string' then return end
    if OnCooldown(src, 'equip', 0.4) then return end

    local item = BRFindShopItem(itemId)
    if not item or not item.weapon then return end
    if not OwnsItem(src, itemId) then return end

    SetEquipped(src, itemId, equipped and true or false)
    Notify(src, BRLocale('skin_equipped'))
    TriggerClientEvent('br:client:updateOwned', src, GetOwnedItems(src))
end)

-- ============================== ADMIN HELPER ==============================

RegisterCommand('brgive', function(source, args)
    if source ~= 0 and not IsPlayerAceAllowed(source, 'command.brgive') then return end
    local target = tonumber(args[1])
    local currency = args[2]
    local amount = tonumber(args[3]) or 0
    if not target or not currency then
        print('usage: brgive <playerId> <Gold|Diamonds> <amount>')
        return
    end
    local stats = GetPlayerStats(target)
    if not stats then print('player not found') return end
    if currency == 'Gold' then
        stats.gold = (stats.gold or 0) + amount
    elseif currency == 'Diamonds' then
        stats.diamonds = (stats.diamonds or 0) + amount
    else
        print('currency must be Gold or Diamonds')
        return
    end
    UpdatePlayerStats(target, stats)
    SyncStats(target, stats)
    Notify(target, ('You received %s %s.'):format(amount, currency))
end, true)
