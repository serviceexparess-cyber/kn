-- Leaderboards, match history requests and end-of-match rewards.

local LEADERBOARD_COLUMNS = {
    kills = 'kills',
    wins = 'wins',
    xp = 'xp'
}

local function memoryLeaderboard(column, limit)
    local rows = {}
    for _, stats in pairs(BRGetMemoryStats()) do
        rows[#rows + 1] = {
            name = stats.name or 'Unknown',
            kills = stats.kills or 0,
            wins = stats.wins or 0,
            matches = stats.matches or 0,
            xp = stats.xp or 0,
            level = BRLevelFromXp(stats.xp or 0)
        }
    end
    table.sort(rows, function(a, b)
        if a[column] == b[column] then return (a.xp or 0) > (b.xp or 0) end
        return (a[column] or 0) > (b[column] or 0)
    end)
    while #rows > limit do table.remove(rows) end
    return rows
end

function BuildLeaderboard(sortKey, limit)
    local column = LEADERBOARD_COLUMNS[sortKey] or 'kills'
    limit = math.min(tonumber(limit) or Config.Leaderboard.limit, 50)

    if not BRHasDatabase() then
        return memoryLeaderboard(column, limit)
    end

    -- Column is resolved from a fixed whitelist above, never interpolated from
    -- client input, so this cannot be turned into SQL injection.
    local sql = ([[
        SELECT name, kills, wins, matches, xp, level
        FROM br_players
        ORDER BY %s DESC, xp DESC
        LIMIT ?
    ]]):format(column)

    local rows = BRQuery(sql, { limit }) or {}
    local out = {}
    for _, row in ipairs(rows) do
        out[#out + 1] = {
            name = row.name or 'Unknown',
            kills = row.kills or 0,
            wins = row.wins or 0,
            matches = row.matches or 0,
            xp = row.xp or 0,
            level = row.level or BRLevelFromXp(row.xp or 0)
        }
    end
    return out
end

RegisterNetEvent('br:server:requestLeaderboard', function(sortKey)
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'leaderboard', 2) then return end
    if type(sortKey) ~= 'string' or not LEADERBOARD_COLUMNS[sortKey] then
        sortKey = 'kills'
    end
    TriggerClientEvent('br:client:leaderboard', src, {
        sort = sortKey,
        rows = BuildLeaderboard(sortKey, Config.Leaderboard.limit)
    })
end)

RegisterNetEvent('br:server:requestHistory', function()
    local src = source
    if not EnsureBRPlayer(src) then return end
    if OnCooldown(src, 'history', 2) then return end
    TriggerClientEvent('br:client:history', src, GetMatchHistory(src, 10))
end)

-- =============================== REWARDS ==================================

-- Applies rewards for one player at the end of a match and returns the deltas
-- so they can be shown on the summary screen.
function GrantMatchRewards(src, result)
    local stats = GetPlayerStats(src)
    if not stats then return nil end

    local rewards = Config.Rewards
    local gold, xp, diamonds = 0, 0, 0

    gold = gold + rewards.participation.gold
    xp = xp + rewards.participation.xp

    local kills = result.kills or 0
    gold = gold + (kills * rewards.perKill.gold)
    xp = xp + (kills * rewards.perKill.xp)

    if result.won then
        gold = gold + rewards.win.gold
        xp = xp + rewards.win.xp
        diamonds = diamonds + (rewards.win.diamonds or 0)
    end

    local levelBefore = BRLevelFromXp(stats.xp or 0)

    stats.gold = (stats.gold or 0) + gold
    stats.xp = (stats.xp or 0) + xp
    stats.diamonds = (stats.diamonds or 0) + diamonds
    stats.kills = (stats.kills or 0) + kills
    stats.matches = (stats.matches or 0) + 1
    if result.won then
        stats.wins = (stats.wins or 0) + 1
    else
        stats.deaths = (stats.deaths or 0) + 1
    end

    UpdatePlayerStats(src, stats)
    SyncStats(src, stats)

    local levelAfter = BRLevelFromXp(stats.xp or 0)

    RecordMatch(src, {
        mode = result.mode,
        placement = result.placement,
        totalPlayers = result.totalPlayers,
        kills = kills,
        damage = result.damage or 0,
        survived = result.survived or 0,
        won = result.won and true or false
    })

    return {
        gold = gold,
        xp = xp,
        diamonds = diamonds,
        levelUp = levelAfter > levelBefore,
        level = levelAfter
    }
end
