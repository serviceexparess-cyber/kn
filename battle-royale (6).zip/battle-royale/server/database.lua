-- oxmysql is detected at runtime. If it is absent the resource still runs, with
-- stats kept in memory until restart.

local hasDb = false
local memStats = {}      -- identifier -> stats
local memInventory = {}  -- identifier -> { [itemId] = { type=, equipped= } }
local memHistory = {}    -- identifier -> { rows }
local identCache = {}    -- src -> identifier

local function dbQuery(sql, params)
    local p = promise.new()
    exports.oxmysql:query(sql, params, function(result) p:resolve(result) end)
    return Citizen.Await(p)
end

local function dbExecute(sql, params)
    local p = promise.new()
    exports.oxmysql:update(sql, params, function(result) p:resolve(result) end)
    return Citizen.Await(p)
end

-- ============================ SCHEMA MIGRATION ============================
-- The resource creates and repairs its own tables at boot, so importing
-- database.sql by hand is optional. This also fixes servers that already have
-- an older br_* table missing one of the newer columns (the classic
-- "Unknown column 'equipped' in 'field list'" error).

local CREATE_TABLES = {
    [1] = [[CREATE TABLE IF NOT EXISTS br_players (
        id INT AUTO_INCREMENT PRIMARY KEY,
        citizenid VARCHAR(64) NOT NULL UNIQUE,
        name VARCHAR(64) DEFAULT NULL,
        xp INT NOT NULL DEFAULT 0,
        level INT NOT NULL DEFAULT 1,
        kills INT NOT NULL DEFAULT 0,
        deaths INT NOT NULL DEFAULT 0,
        wins INT NOT NULL DEFAULT 0,
        matches INT NOT NULL DEFAULT 0,
        gold INT NOT NULL DEFAULT 0,
        diamonds INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_kills (kills), INDEX idx_wins (wins), INDEX idx_xp (xp)
    )]],
    [2] = [[CREATE TABLE IF NOT EXISTS br_inventory (
        id INT AUTO_INCREMENT PRIMARY KEY,
        citizenid VARCHAR(64) NOT NULL,
        item_id VARCHAR(64) NOT NULL,
        item_type VARCHAR(32) NOT NULL DEFAULT 'Unknown',
        equipped TINYINT(1) NOT NULL DEFAULT 0,
        acquired_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_owned (citizenid, item_id),
        INDEX idx_owner (citizenid)
    )]],
    [3] = [[CREATE TABLE IF NOT EXISTS br_match_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        citizenid VARCHAR(64) NOT NULL,
        mode VARCHAR(16) NOT NULL,
        placement INT NOT NULL DEFAULT 0,
        total_players INT NOT NULL DEFAULT 0,
        kills INT NOT NULL DEFAULT 0,
        damage INT NOT NULL DEFAULT 0,
        survived_seconds INT NOT NULL DEFAULT 0,
        won TINYINT(1) NOT NULL DEFAULT 0,
        played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_player_time (citizenid, played_at)
    )]]
}

-- Columns every table must have, in order, so a legacy table can be topped up.
local REQUIRED_COLUMNS = {
    br_players = {
        { 'citizenid',   "VARCHAR(64) NOT NULL" },
        { 'name',        "VARCHAR(64) DEFAULT NULL" },
        { 'xp',          "INT NOT NULL DEFAULT 0" },
        { 'level',       "INT NOT NULL DEFAULT 1" },
        { 'kills',       "INT NOT NULL DEFAULT 0" },
        { 'deaths',      "INT NOT NULL DEFAULT 0" },
        { 'wins',        "INT NOT NULL DEFAULT 0" },
        { 'matches',     "INT NOT NULL DEFAULT 0" },
        { 'gold',        "INT NOT NULL DEFAULT 0" },
        { 'diamonds',    "INT NOT NULL DEFAULT 0" },
        { 'created_at',  "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" }
    },
    br_inventory = {
        { 'citizenid',   "VARCHAR(64) NOT NULL" },
        { 'item_id',     "VARCHAR(64) NOT NULL" },
        { 'item_type',   "VARCHAR(32) NOT NULL DEFAULT 'Unknown'" },
        { 'equipped',    "TINYINT(1) NOT NULL DEFAULT 0" },
        { 'acquired_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" }
    },
    br_match_history = {
        { 'citizenid',        "VARCHAR(64) NOT NULL" },
        { 'mode',             "VARCHAR(16) NOT NULL DEFAULT 'Solo'" },
        { 'placement',        "INT NOT NULL DEFAULT 0" },
        { 'total_players',    "INT NOT NULL DEFAULT 0" },
        { 'kills',            "INT NOT NULL DEFAULT 0" },
        { 'damage',           "INT NOT NULL DEFAULT 0" },
        { 'survived_seconds', "INT NOT NULL DEFAULT 0" },
        { 'won',              "TINYINT(1) NOT NULL DEFAULT 0" },
        { 'played_at',        "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" }
    }
}

local TABLE_ORDER = { 'br_players', 'br_inventory', 'br_match_history' }

-- Returns a set of the column names a table currently has, or nil on failure.
local function existingColumns(tableName)
    local ok, rows = pcall(dbQuery, [[
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ]], { tableName })
    if not ok or type(rows) ~= 'table' then return nil end

    local set = {}
    for _, row in ipairs(rows) do
        -- oxmysql may return the key as COLUMN_NAME or column_name.
        local col = row.COLUMN_NAME or row.column_name
        if col then set[string.lower(col)] = true end
    end
    return set
end

local function ensureSchema()
    for i = 1, #TABLE_ORDER do
        local ok, err = pcall(dbExecute, CREATE_TABLES[i], {})
        if not ok then
            print(('[battle-royale] could not create %s: %s')
                :format(TABLE_ORDER[i], tostring(err)))
        end
    end

    local added, blocked = 0, false
    for _, tableName in ipairs(TABLE_ORDER) do
        local cols = existingColumns(tableName)
        if cols then
            if not cols.citizenid then
                -- A table of that name exists but is not ours; adding columns
                -- to it would be guesswork, so stop and say so clearly.
                print(('[battle-royale] TABLE `%s` EXISTS BUT HAS NO `citizenid` COLUMN.')
                    :format(tableName))
                print(('[battle-royale] It is not a Battle Royale table. Rename or drop it, ' ..
                    'then restart the resource: RENAME TABLE `%s` TO `%s_backup`;')
                    :format(tableName, tableName))
                blocked = true
            else
                for _, def in ipairs(REQUIRED_COLUMNS[tableName]) do
                    local name, ddl = def[1], def[2]
                    if not cols[string.lower(name)] then
                        local ok = pcall(dbExecute, ('ALTER TABLE `%s` ADD COLUMN `%s` %s')
                            :format(tableName, name, ddl), {})
                        if ok then
                            added = added + 1
                            print(('[battle-royale] schema updated: added `%s`.`%s`')
                                :format(tableName, name))
                        else
                            print(('[battle-royale] could not add `%s`.`%s` - import database.sql manually.')
                                :format(tableName, name))
                            blocked = true
                        end
                    end
                end
            end
        end
    end

    if blocked then return false end
    if added > 0 then
        print(('[battle-royale] schema migration done (%d column(s) added).'):format(added))
    end

    -- oxmysql swallows SQL errors (it prints them and resolves with nil) rather
    -- than raising, so pcall above cannot be trusted. Re-read the real schema
    -- and refuse to enable the database unless every column is actually there.
    for _, tableName in ipairs(TABLE_ORDER) do
        local cols = existingColumns(tableName)
        if not cols then
            print(('[battle-royale] could not read the schema of `%s`.'):format(tableName))
            return false
        end
        for _, def in ipairs(REQUIRED_COLUMNS[tableName]) do
            if not cols[string.lower(def[1])] then
                print(('[battle-royale] MISSING COLUMN `%s`.`%s` - import database.sql, ' ..
                    'or drop the old table: DROP TABLE `%s`;')
                    :format(tableName, def[1], tableName))
                return false
            end
        end
    end

    return true
end

CreateThread(function()
    -- oxmysql may start after us, so poll briefly instead of checking once.
    local found = false
    for _ = 1, 30 do
        if GetResourceState('oxmysql') == 'started' then
            found = true
            break
        end
        Wait(500)
    end

    if not found then
        print('[battle-royale] oxmysql NOT found - stats are in memory only (reset on restart).')
        return
    end

    -- Verify and repair the schema BEFORE any other file is allowed to query,
    -- so a half-migrated table can never be read.
    if ensureSchema() then
        hasDb = true
        print('[battle-royale] oxmysql detected, schema OK - stats are persistent.')
    else
        print('[battle-royale] schema unusable - falling back to in-memory stats for this session.')
    end
end)

function BRHasDatabase() return hasDb end

local function safeQuery(sql, params)
    if not hasDb then return nil end
    local ok, res = pcall(dbQuery, sql, params)
    if not ok then
        print(('[battle-royale] DB query failed: %s'):format(tostring(res)))
        return nil
    end
    return res
end

local function safeExecute(sql, params)
    if not hasDb then return nil end
    local ok, res = pcall(dbExecute, sql, params)
    if not ok then
        print(('[battle-royale] DB write failed: %s'):format(tostring(res)))
        return nil
    end
    return res
end

function BRQuery(sql, params) return safeQuery(sql, params) end
function BRExecute(sql, params) return safeExecute(sql, params) end

-- Exposed so the leaderboard can be built without a database.
function BRGetMemoryStats() return memStats end

-- ============================== IDENTIFIERS ===============================

function GetIdentifier(src)
    if identCache[src] then return identCache[src] end

    local identifier
    if Framework.QBCore then
        local Player = Framework.QBCore.Functions.GetPlayer(src)
        if Player then identifier = Player.PlayerData.citizenid end
    elseif Framework.ESX then
        local xPlayer = Framework.ESX.GetPlayerFromId(src)
        if xPlayer then identifier = xPlayer.identifier end
    end

    if not identifier then
        -- Standalone: a license is stable across sessions, the server id is not.
        for _, id in ipairs(GetPlayerIdentifiers(src) or {}) do
            if id:find('^license:') then identifier = id break end
        end
    end

    identifier = identifier or ('src:' .. tostring(src))
    identCache[src] = identifier
    return identifier
end

AddEventHandler('playerDropped', function()
    identCache[source] = nil
end)

-- ================================= STATS ==================================

local function defaultStats()
    return {
        xp = 0, level = 1, kills = 0, deaths = 0,
        wins = 0, matches = 0, gold = 0, diamonds = 0
    }
end

function GetPlayerStats(src)
    local identifier = GetIdentifier(src)
    if not identifier then return nil end

    if not hasDb then
        memStats[identifier] = memStats[identifier] or defaultStats()
        memStats[identifier].name = GetDisplayName(src)
        return memStats[identifier]
    end

    local result = safeQuery('SELECT * FROM br_players WHERE citizenid = ?', { identifier })
    if result and result[1] then return result[1] end

    safeExecute('INSERT IGNORE INTO br_players (citizenid, name) VALUES (?, ?)',
        { identifier, GetDisplayName(src) })

    local created = safeQuery('SELECT * FROM br_players WHERE citizenid = ?', { identifier })
    if created and created[1] then return created[1] end

    -- DB unreachable: fall back so gameplay never blocks on it.
    memStats[identifier] = memStats[identifier] or defaultStats()
    return memStats[identifier]
end

function UpdatePlayerStats(src, stats)
    local identifier = GetIdentifier(src)
    if not identifier or not stats then return false end

    -- Level is always derived from XP, never trusted from elsewhere.
    stats.level = BRLevelFromXp(stats.xp or 0)

    if not hasDb then
        stats.name = GetDisplayName(src)
        memStats[identifier] = stats
        return true
    end

    safeExecute([[
        UPDATE br_players SET name = ?, xp = ?, level = ?, kills = ?, deaths = ?,
            wins = ?, matches = ?, gold = ?, diamonds = ? WHERE citizenid = ?
    ]], {
        GetDisplayName(src), stats.xp or 0, stats.level or 1, stats.kills or 0,
        stats.deaths or 0, stats.wins or 0, stats.matches or 0,
        stats.gold or 0, stats.diamonds or 0, identifier
    })
    return true
end

function BuildStatsPayload(stats)
    local level, into, needed = BRLevelFromXp(stats.xp or 0)
    return {
        gold = stats.gold or 0,
        diamonds = stats.diamonds or 0,
        kills = stats.kills or 0,
        deaths = stats.deaths or 0,
        wins = stats.wins or 0,
        matches = stats.matches or 0,
        xp = stats.xp or 0,
        level = level,
        xpInto = into,
        xpNeeded = needed
    }
end

function SyncStats(src, stats)
    TriggerClientEvent('br:client:updateStats', src, BuildStatsPayload(stats))
end

-- =============================== INVENTORY ================================

-- Returns { owned = { itemId = true }, equipped = { itemId = true } }
function GetOwnedItems(src)
    local identifier = GetIdentifier(src)
    local owned, equipped = {}, {}

    if not hasDb then
        for itemId, data in pairs(memInventory[identifier] or {}) do
            owned[itemId] = true
            if data.equipped then equipped[itemId] = true end
        end
        return { owned = owned, equipped = equipped }
    end

    local rows = safeQuery('SELECT item_id, equipped FROM br_inventory WHERE citizenid = ?', { identifier })
    for _, row in ipairs(rows or {}) do
        owned[row.item_id] = true
        if row.equipped == 1 or row.equipped == true then equipped[row.item_id] = true end
    end
    return { owned = owned, equipped = equipped }
end

function OwnsItem(src, itemId)
    local inv = GetOwnedItems(src)
    return inv.owned[itemId] == true
end

function AddItem(src, itemId, itemType)
    local identifier = GetIdentifier(src)
    if not hasDb then
        memInventory[identifier] = memInventory[identifier] or {}
        memInventory[identifier][itemId] = { type = itemType, equipped = false }
        return true
    end
    safeExecute('INSERT IGNORE INTO br_inventory (citizenid, item_id, item_type) VALUES (?, ?, ?)',
        { identifier, itemId, itemType })
    return true
end

-- Equipping a skin unequips any other skin for the SAME weapon, so a weapon
-- can never resolve to two tints.
function SetEquipped(src, itemId, equipped)
    local identifier = GetIdentifier(src)
    local item = BRFindShopItem(itemId)
    if not item then return false end

    if not hasDb then
        local inv = memInventory[identifier]
        if not inv or not inv[itemId] then return false end
        if equipped and item.weapon then
            for otherId, data in pairs(inv) do
                local other = BRFindShopItem(otherId)
                if other and other.weapon == item.weapon then data.equipped = false end
            end
        end
        inv[itemId].equipped = equipped and true or false
        return true
    end

    if equipped and item.weapon then
        local siblings = {}
        for _, candidate in ipairs(Config.ShopItems.WeaponSkins or {}) do
            if candidate.weapon == item.weapon then siblings[#siblings + 1] = candidate.id end
        end
        for _, siblingId in ipairs(siblings) do
            safeExecute('UPDATE br_inventory SET equipped = 0 WHERE citizenid = ? AND item_id = ?',
                { identifier, siblingId })
        end
    end

    safeExecute('UPDATE br_inventory SET equipped = ? WHERE citizenid = ? AND item_id = ?',
        { equipped and 1 or 0, identifier, itemId })
    return true
end

-- Skin ids the player currently has equipped, used to tint looted weapons.
function GetEquippedSkins(src)
    local inv = GetOwnedItems(src)
    local list = {}
    for itemId in pairs(inv.equipped) do
        local item = BRFindShopItem(itemId)
        if item and item.weapon then list[#list + 1] = itemId end
    end
    return list
end

-- ============================= MATCH HISTORY ==============================

function RecordMatch(src, row)
    local identifier = GetIdentifier(src)
    if not hasDb then
        memHistory[identifier] = memHistory[identifier] or {}
        table.insert(memHistory[identifier], 1, row)
        while #memHistory[identifier] > 20 do
            table.remove(memHistory[identifier])
        end
        return
    end
    safeExecute([[
        INSERT INTO br_match_history
            (citizenid, mode, placement, total_players, kills, damage, survived_seconds, won)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        identifier, row.mode, row.placement, row.totalPlayers,
        row.kills, row.damage or 0, row.survived or 0, row.won and 1 or 0
    })
end

function GetMatchHistory(src, limit)
    local identifier = GetIdentifier(src)
    limit = math.min(tonumber(limit) or 10, 25)

    if not hasDb then
        local out = {}
        for i, row in ipairs(memHistory[identifier] or {}) do
            if i > limit then break end
            out[#out + 1] = {
                mode = row.mode, placement = row.placement, totalPlayers = row.totalPlayers,
                kills = row.kills, survived = row.survived, won = row.won, playedAt = 'recent'
            }
        end
        return out
    end

    local rows = safeQuery([[
        SELECT mode, placement, total_players, kills, survived_seconds, won,
               DATE_FORMAT(played_at, '%Y-%m-%d %H:%i') AS played_at
        FROM br_match_history WHERE citizenid = ?
        ORDER BY played_at DESC LIMIT ?
    ]], { identifier, limit })

    local out = {}
    for _, row in ipairs(rows or {}) do
        out[#out + 1] = {
            mode = row.mode,
            placement = row.placement,
            totalPlayers = row.total_players,
            kills = row.kills,
            survived = row.survived_seconds,
            won = row.won == 1 or row.won == true,
            playedAt = row.played_at
        }
    end
    return out
end
