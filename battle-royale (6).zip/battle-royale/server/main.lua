Framework = { QBCore = nil, ESX = nil }

CreateThread(function()
    if GetResourceState('qb-core') == 'started' then
        Framework.QBCore = exports['qb-core']:GetCoreObject()
    elseif GetResourceState('es_extended') == 'started' then
        Framework.ESX = exports['es_extended']:getSharedObject()
    end
end)

-- ================================= STATE ==================================

BRPlayers  = {}   -- src -> true (connected and known to this resource)
Rooms      = {}   -- code -> room table
PlayerRoom = {}   -- src  -> room code
Games      = {}   -- gameId -> game table
PlayerGame = {}   -- src  -> gameId
PendingInvites = {} -- src -> { code, from, expires }

-- Global on purpose: several server files share it. Declaring it `local` in one
-- file and reading it in another silently yields nil and throws on index.
Cooldowns = {}

-- ============================== RATE LIMITING =============================

-- ============================ PLAYER REGISTRY =============================
-- Registration used to happen ONLY inside br:server:requestMenu, so the table
-- was empty for anyone already connected when the resource (re)started, and
-- every handler bailed out at `if not BRPlayers[src]`. Nothing was logged and
-- every button looked dead. Registration is now lazy: any handler can register
-- a genuinely connected player on the spot.

function EnsureBRPlayer(src)
    if BRPlayers[src] then return true end
    src = tonumber(src)
    if not src or src <= 0 then return false end
    -- GetPlayerName returns nil for a source that is not actually connected,
    -- which keeps this from registering forged or stale sources.
    if not GetPlayerName(src) then return false end
    BRPlayers[src] = true
    return true
end

-- Register everyone already online when the resource starts.
AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, src in ipairs(GetPlayers()) do
        EnsureBRPlayer(tonumber(src))
    end
end)

AddEventHandler('playerJoining', function()
    EnsureBRPlayer(source)
end)

function OnCooldown(src, key, seconds)
    Cooldowns[src] = Cooldowns[src] or {}
    -- os.clock() measures CPU time consumed by the server process, not elapsed
    -- wall time: it advances far slower than real seconds, so a 2s cooldown
    -- could lock a button for minutes. GetGameTimer() is real milliseconds.
    local now = GetGameTimer() / 1000
    local last = Cooldowns[src][key]
    if last and (now - last) < seconds then
        return true
    end
    Cooldowns[src][key] = now
    return false
end

-- =============================== UTILITIES ================================

function Notify(src, message)
    if not src or not message then return end
    TriggerClientEvent('br:client:notify', src, message)
end

function GetDisplayName(src)
    local name = GetPlayerName(src)
    if not name or name == '' then return ('Player %s'):format(src) end
    return (BRSanitiseText(name, 24)) or ('Player %s'):format(src)
end

-- Only characters that are unambiguous when read aloud or retyped.
local CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

function GenerateRoomCode()
    for _ = 1, 50 do
        local code = {}
        for _ = 1, Config.Rooms.codeLength do
            local i = math.random(#CODE_ALPHABET)
            code[#code + 1] = CODE_ALPHABET:sub(i, i)
        end
        local candidate = table.concat(code)
        if not Rooms[candidate] then return candidate end
    end
    return nil
end

function CountRooms()
    local n = 0
    for _ in pairs(Rooms) do n = n + 1 end
    return n
end

-- ============================== MENU REQUEST ==============================

RegisterNetEvent('br:server:requestMenu', function()
    local src = source
    if OnCooldown(src, 'menu', 0.5) then return end
    EnsureBRPlayer(src)

    -- Guarded calls: if a server file is missing from fxmanifest.lua the menu
    -- still opens (degraded) instead of throwing a nil-value error every time.
    -- The integrity check at the bottom of this file names the missing file.
    local stats = GetPlayerStats and GetPlayerStats(src) or {}
    local owned = GetOwnedItems and GetOwnedItems(src) or { owned = {}, equipped = {} }

    local roomPayload = nil
    if BuildRoomPayload and PlayerRoom[src] and Rooms[PlayerRoom[src]] then
        roomPayload = BuildRoomPayload(Rooms[PlayerRoom[src]])
        roomPayload.you = src
    end

    TriggerClientEvent('br:client:openMenu', src, {
        stats = BuildStatsPayload and BuildStatsPayload(stats) or {},
        shop = Config.ShopItems,
        shopOrder = Config.ShopOrder,
        modes = BuildModePayload(),
        owned = owned,
        rooms = BuildRoomList and BuildRoomList() or {},
        limits = Config.Rooms.limits,
        defaults = Config.Rooms.defaults,
        room = roomPayload
    })
end)

function BuildModePayload()
    local modes = {}
    for _, key in ipairs(Config.ModeOrder) do
        local mode = Config.GameModes[key]
        if mode then
            modes[#modes + 1] = {
                key = key,
                label = mode.label or key:upper(),
                teamSize = mode.teamSize or 1,
                minPlayers = BRGetMinPlayers(key),
                maxPlayers = mode.maxPlayers
            }
        end
    end
    return modes
end

-- ============================== DISCONNECTS ===============================

AddEventHandler('playerDropped', function()
    local src = source
    -- Order matters: remove from the match first so placements resolve, then
    -- from the room, then wipe per-player state.
    if PlayerGame[src] then
        HandlePlayerLeftGame(src, 'disconnect')
    end
    if PlayerRoom[src] then
        LeaveRoom(src, true)
    end
    BRPlayers[src] = nil
    Cooldowns[src] = nil
    PlayerRoom[src] = nil
    PlayerGame[src] = nil
    PendingInvites[src] = nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for gameId, game in pairs(Games) do
        game.active = false
        for src in pairs(game.alive or {}) do
            TriggerClientEvent('br:client:forceExit', src)
        end
        Games[gameId] = nil
    end
end)

-- ============================ INTEGRITY CHECK =============================
-- Every server file registers a function the others rely on. If a file is not
-- listed in fxmanifest.lua it simply never loads, and the first symptom is an
-- obscure "attempt to call a nil value" much later. This runs once at boot and
-- names the exact file that is missing instead.

CreateThread(function()
    Wait(2000) -- let every other server_script finish loading

    local expected = {
        { file = 'server/database.lua', fn = 'BuildStatsPayload' },
        { file = 'server/stats.lua',    fn = 'BuildLeaderboard'  },
        { file = 'server/rooms.lua',    fn = 'BuildRoomList'     },
        { file = 'server/game.lua',     fn = 'StartMatchFromRoom' },
        { file = 'server/loot.lua',     fn = 'BRLootModuleLoaded' }
    }

    local missing = {}
    for _, entry in ipairs(expected) do
        if type(_G[entry.fn]) ~= 'function' then
            missing[#missing + 1] = entry.file
        end
    end

    if #missing == 0 then
        print(('[battle-royale] v%s loaded - all server modules present.')
            :format(GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '?'))
        return
    end

    print('[battle-royale] =====================================================')
    print('[battle-royale] INSTALLATION INCOMPLETE - the resource will not work.')
    print('[battle-royale] These files are NOT being loaded:')
    for _, file in ipairs(missing) do
        print(('[battle-royale]   - %s'):format(file))
    end
    print('[battle-royale] Your fxmanifest.lua is from an OLDER version.')
    print('[battle-royale] Delete resources/battle-royale entirely, then extract')
    print('[battle-royale] the v3 zip again. Do not copy over the old folder.')
    print('[battle-royale] =====================================================')
end)

-- Server half of /brdiag (see client/main.lua). Prints to the server console.
RegisterNetEvent('br:server:diag', function()
    local src = source
    local modules = {
        { file = 'server/database.lua', fn = 'BuildStatsPayload'  },
        { file = 'server/stats.lua',    fn = 'BuildLeaderboard'   },
        { file = 'server/rooms.lua',    fn = 'BuildRoomList'      },
        { file = 'server/game.lua',     fn = 'StartMatchFromRoom' },
        { file = 'server/loot.lua',     fn = 'BRLootModuleLoaded' }
    }

    print('[brdiag] ---------------- SERVER ----------------')
    print(('[brdiag] resource version : %s')
        :format(GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '?'))

    local missing = 0
    for _, entry in ipairs(modules) do
        local loaded = type(_G[entry.fn]) == 'function'
        if not loaded then missing = missing + 1 end
        print(('[brdiag] %-22s %s'):format(entry.file, loaded and 'OK' or '*** NOT LOADED ***'))
    end

    print(('[brdiag] database=%s  rooms open=%d')
        :format(tostring(BRHasDatabase and BRHasDatabase() or false),
                CountRooms and CountRooms() or -1))
    print(('[brdiag] src=%d name=%s registered=%s room=%s inGame=%s identifier=%s')
        :format(src, tostring(GetPlayerName(src)),
                tostring(BRPlayers[src] and true or false),
                tostring(PlayerRoom[src] or 'none'),
                tostring(PlayerGame[src] or 'none'),
                tostring(GetIdentifier and GetIdentifier(src) or '?')))

    if missing > 0 then
        print(('[brdiag] %d SERVER FILE(S) MISSING -> fxmanifest.lua is from an older version.')
            :format(missing))
        Notify(src, ('%d server file(s) not loaded - see server console.'):format(missing))
    else
        Notify(src, 'Diagnostic printed in the server console.')
    end
end)
