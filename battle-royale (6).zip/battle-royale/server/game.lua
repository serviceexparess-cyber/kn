-- Match lifecycle: start, plane drop path, phased gas zone, kills, placements.

local gameCounter = 0

-- Builds a flight line that crosses the map centre on a random bearing, so the
-- drop route differs every match.
local function buildFlightPath()
    local plane = Config.PlaneDrop
    local center = Config.Map.center
    local angle = math.random() * math.pi * 2
    local half = plane.pathLength / 2

    local dx, dy = math.cos(angle), math.sin(angle)
    return {
        startPos = { x = center.x - dx * half, y = center.y - dy * half, z = plane.altitude },
        endPos   = { x = center.x + dx * half, y = center.y + dy * half, z = plane.altitude },
        altitude = plane.altitude,
        speed = plane.speed,
        model = plane.model,
        forcedJumpAfter = plane.forcedJumpAfter,
        autoDeployHeight = plane.autoDeployHeight
    }
end

-- Rolls a tier per crate for this match so the same crate is not always the
-- same reward.
local function buildCrateTiers()
    local tiers = {}
    for _, crate in ipairs(Config.LootCrates) do
        tiers[crate.id] = BRRollTier()
    end
    return tiers
end

function StartMatchFromRoom(room)
    if not room or room.state ~= 'lobby' then return end

    local players = {}
    for _, src in ipairs(room.order) do
        players[#players + 1] = src
    end
    if #players == 0 then return end

    gameCounter = gameCounter + 1
    local gameId = gameCounter

    local usePlane = room.settings.planeDrop and Config.PlaneDrop.enabled
    local flight = usePlane and buildFlightPath() or nil

    local game = {
        id = gameId,
        room = room.code,
        mode = room.mode,
        settings = room.settings,
        alive = {},
        aliveCount = #players,
        totalPlayers = #players,
        kills = {},
        names = {},
        placements = {},          -- src -> placement
        nextPlacement = #players, -- first death takes the LAST place
        crateTiers = buildCrateTiers(),
        lootedCrates = {},
        center = Config.Map.center,
        radius = Config.Map.initialRadius,
        phaseIndex = 0,
        damage = 0,
        startedAt = os.time(),
        active = true
    }

    for _, src in ipairs(players) do
        game.alive[src] = true
        game.kills[src] = 0
        game.names[src] = room.players[src] and room.players[src].name or GetDisplayName(src)
        PlayerGame[src] = gameId
    end
    Games[gameId] = game

    room.state = 'ingame'
    room.countdown = nil
    SyncRoom(room)
    BroadcastRoomList()

    for _, src in ipairs(players) do
        TriggerClientEvent('br:client:startGame', src, {
            gameId = gameId,
            mode = game.mode,
            totalPlayers = game.totalPlayers,
            planeDrop = usePlane,
            flight = flight,
            spawn = (not usePlane) and SelectGroundSpawn() or nil,
            center = { x = game.center.x, y = game.center.y, z = game.center.z },
            radius = game.radius,
            crates = BuildCratePayload(game),
            skins = GetEquippedSkins(src),
            dropsEnabled = room.settings.dropsEnabled,
            friendlyFire = room.settings.friendlyFire
        })
    end

    BroadcastAlive(game)
    StartZoneLoop(gameId)
    BRDebug('match started', gameId, game.mode, #players, usePlane and 'plane' or 'ground')
end

function SelectGroundSpawn()
    local spawn = Config.SpawnPoints[math.random(#Config.SpawnPoints)]
    return { x = spawn.x, y = spawn.y, z = spawn.z }
end

function BuildCratePayload(game)
    local out = {}
    for _, crate in ipairs(Config.LootCrates) do
        out[#out + 1] = {
            id = crate.id,
            x = crate.coords.x, y = crate.coords.y, z = crate.coords.z,
            tier = game.crateTiers[crate.id]
        }
    end
    return out
end

function BroadcastAlive(game)
    if not game then return end
    for src in pairs(game.alive) do
        TriggerClientEvent('br:client:updateAlive', src, {
            alive = game.aliveCount,
            total = game.totalPlayers,
            kills = game.kills[src] or 0
        })
    end
end

-- =============================== GAS ZONE =================================

function StartZoneLoop(gameId)
    CreateThread(function()
        for phaseIndex, phase in ipairs(Config.ZonePhases) do
            local game = Games[gameId]
            if not game or not game.active then return end

            local speed = game.settings.shrinkSpeed or 1.0
            local waitTime = math.max(1, math.floor(phase.wait / speed))
            local shrinkTime = math.max(1, math.floor(phase.shrink / speed))

            game.phaseIndex = phaseIndex
            game.damage = 0   -- no gas damage while the zone is static

            -- Pick where the next circle will sit before the countdown starts,
            -- so players can see and run to it.
            local startRadius = game.radius
            local targetRadius = math.min(phase.radius, startRadius)
            local targetCenter = PickNextCenter(game, startRadius, targetRadius)

            -- Phase 1: waiting, next circle already visible.
            for remaining = waitTime, 1, -1 do
                game = Games[gameId]
                if not game or not game.active then return end
                BroadcastZone(game, {
                    state = 'waiting',
                    remaining = remaining,
                    nextCenter = targetCenter,
                    nextRadius = targetRadius,
                    phase = phaseIndex,
                    totalPhases = #Config.ZonePhases
                })
                Wait(Config.Zone.tickRate)
            end

            -- Phase 2: shrinking, gas now hurts.
            local fromCenter = game.center
            game.damage = math.floor((phase.damage or 1) * ((game.settings.gasDamage or 5) / 5))
            for step = 1, shrinkTime do
                game = Games[gameId]
                if not game or not game.active then return end
                local t = step / shrinkTime
                game.radius = startRadius + (targetRadius - startRadius) * t
                game.center = vector3(
                    fromCenter.x + (targetCenter.x - fromCenter.x) * t,
                    fromCenter.y + (targetCenter.y - fromCenter.y) * t,
                    fromCenter.z
                )
                BroadcastZone(game, {
                    state = 'shrinking',
                    remaining = shrinkTime - step,
                    nextCenter = targetCenter,
                    nextRadius = targetRadius,
                    phase = phaseIndex,
                    totalPhases = #Config.ZonePhases
                })
                Wait(Config.Zone.tickRate)
            end

            game = Games[gameId]
            if not game or not game.active then return end
            game.radius = targetRadius
            game.center = vector3(targetCenter.x, targetCenter.y, targetCenter.z)
        end

        -- Zone fully closed: everyone still alive takes damage until one remains.
        local game = Games[gameId]
        if game and game.active then
            game.radius = 0.0
            game.damage = Config.ZonePhases[#Config.ZonePhases].damage or 25
            while Games[gameId] and Games[gameId].active do
                BroadcastZone(Games[gameId], {
                    state = 'closed', remaining = 0,
                    nextCenter = { x = game.center.x, y = game.center.y, z = game.center.z },
                    nextRadius = 0.0,
                    phase = #Config.ZonePhases, totalPhases = #Config.ZonePhases
                })
                Wait(Config.Zone.tickRate)
            end
        end
    end)
end

-- Drifts the next circle inward but keeps it inside the current one, so the
-- safe area can never jump somewhere unreachable.
function PickNextCenter(game, currentRadius, nextRadius)
    local maxDrift = math.max(0.0, (currentRadius - nextRadius) * (Config.Zone.driftFactor or 0.6))
    local angle = math.random() * math.pi * 2
    local distance = math.random() * maxDrift
    return {
        x = game.center.x + math.cos(angle) * distance,
        y = game.center.y + math.sin(angle) * distance,
        z = game.center.z
    }
end

function BroadcastZone(game, info)
    if not game then return end
    local payload = {
        center = { x = game.center.x, y = game.center.y, z = game.center.z },
        radius = game.radius,
        damage = game.damage,
        state = info.state,
        remaining = info.remaining,
        nextCenter = info.nextCenter,
        nextRadius = info.nextRadius,
        phase = info.phase,
        totalPhases = info.totalPhases
    }
    for src in pairs(game.alive) do
        TriggerClientEvent('br:client:updateZone', src, payload)
    end
end

-- ============================ DEATHS AND KILLS ============================

RegisterNetEvent('br:server:playerDied', function(killerServerId)
    local src = source
    local gameId = PlayerGame[src]
    if not gameId then return end
    local game = Games[gameId]
    if not game or not game.alive[src] then return end
    if OnCooldown(src, 'died', 1) then return end

    -- Kill credit is validated: the killer must be a different player who is
    -- alive in the SAME match. A crafted client cannot invent kills.
    local killer = tonumber(killerServerId)
    if killer and killer ~= src and game.alive[killer] then
        game.kills[killer] = (game.kills[killer] or 0) + 1
        Notify(killer, BRLocale('killed', game.names[src] or 'a player'))
        TriggerClientEvent('br:client:updateAlive', killer, {
            alive = game.aliveCount - 1,
            total = game.totalPlayers,
            kills = game.kills[killer]
        })
    end

    EliminatePlayer(game, src, 'death')
end)

function EliminatePlayer(game, src, reason)
    if not game or not game.alive[src] then return end

    local placement = game.nextPlacement
    game.alive[src] = nil
    game.aliveCount = math.max(0, game.aliveCount - 1)
    game.nextPlacement = math.max(1, game.nextPlacement - 1)
    game.placements[src] = placement

    local survived = os.time() - game.startedAt

    if reason ~= 'disconnect' then
        local rewards = GrantMatchRewards(src, {
            mode = game.mode,
            placement = placement,
            totalPlayers = game.totalPlayers,
            kills = game.kills[src] or 0,
            survived = survived,
            won = false
        })
        TriggerClientEvent('br:client:matchEnd', src, {
            won = false,
            placement = placement,
            totalPlayers = game.totalPlayers,
            kills = game.kills[src] or 0,
            survived = survived,
            mode = game.mode,
            rewards = rewards
        })
    end

    PlayerGame[src] = nil
    BroadcastAlive(game)
    CheckWinCondition(game)
end

function HandlePlayerLeftGame(src, reason)
    local gameId = PlayerGame[src]
    if not gameId then return end
    local game = Games[gameId]
    PlayerGame[src] = nil
    if not game then return end
    if game.alive[src] then
        EliminatePlayer(game, src, reason or 'leave')
    end
end

function CheckWinCondition(game)
    if not game or not game.active then return end
    if game.aliveCount > 1 then return end

    game.active = false

    local winner
    for src in pairs(game.alive) do winner = src end

    if winner then
        local survived = os.time() - game.startedAt
        local rewards = GrantMatchRewards(winner, {
            mode = game.mode,
            placement = 1,
            totalPlayers = game.totalPlayers,
            kills = game.kills[winner] or 0,
            survived = survived,
            won = true
        })
        TriggerClientEvent('br:client:matchEnd', winner, {
            won = true,
            placement = 1,
            totalPlayers = game.totalPlayers,
            kills = game.kills[winner] or 0,
            survived = survived,
            mode = game.mode,
            rewards = rewards
        })
        game.alive[winner] = nil
        PlayerGame[winner] = nil
    end

    -- Return the room to the lobby so the same group can play again.
    local room = Rooms[game.room]
    if room then
        room.state = 'lobby'
        for _, src in ipairs(room.order) do
            if room.players[src] then room.players[src].ready = false end
        end
        AddSystemChat(room, winner and ('%s won the match.'):format(game.names[winner] or '?')
            or 'Match over.')
        SyncRoom(room)
        BroadcastRoomList()
    end

    Games[game.id] = nil
    BRDebug('match ended', game.id)
end

-- Client reports it finished the parachute drop; purely informational.
RegisterNetEvent('br:server:playerLanded', function()
    local src = source
    if not PlayerGame[src] then return end
    if OnCooldown(src, 'landed', 2) then return end
end)

-- Player abandons the match from the pause/menu.
RegisterNetEvent('br:server:abandonMatch', function()
    local src = source
    if not PlayerGame[src] then return end
    if OnCooldown(src, 'abandon', 2) then return end
    HandlePlayerLeftGame(src, 'leave')
    TriggerClientEvent('br:client:forceExit', src)
end)
