RegisterNetEvent('br:server:lootCrate', function(crateId)
    local src = source
    if not BRPlayers[src] then return end
    if type(crateId) ~= 'string' then return end
    if cooldowns[src] and os.time() - cooldowns[src] < 2 then return end
    cooldowns[src] = os.time()
    local loot = Config.Loot[Config.LootCrates[crateId].tier]
    local item = loot[math.random(#loot)]
    TriggerClientEvent('br:client:notify', src, 'You looted: ' .. item)
end)

RegisterNetEvent('br:server:purchaseItem', function(item, currency)
    local src = source
    if not BRPlayers[src] then return end
    if type(item) ~= 'string' or type(currency) ~= 'string' then return end
    if cooldowns[src] and os.time() - cooldowns[src] < 3 then return end
    cooldowns[src] = os.time()
    local stats = GetPlayerStats(src)
    if not stats then return end
    local price = 0
    for _, shopItem in pairs(Config.ShopItems.Crates) do
        if shopItem.name == item and shopItem.currency == currency then
            price = shopItem.price
            break
        end
    end
    if price == 0 then return end
    if currency == 'Gold' and stats.gold >= price then
        stats.gold = stats.gold - price
    elseif currency == 'Diamonds' and stats.diamonds >= price then
        stats.diamonds = stats.diamonds - price
    else
        TriggerClientEvent('br:client:notify', src, 'Insufficient funds')
        return
    end
    UpdatePlayerStats(src, stats)
    TriggerClientEvent('br:client:notify', src, 'Purchase successful')
end)

AddEventHandler('playerDropped', function()
    local src = source
    cooldowns[src] = nil
end)