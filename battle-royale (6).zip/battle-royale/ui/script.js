/* Battle Royale v3 - interface NUI.
   Aucune dependance externe : tout est natif. */

const $ = (id) => document.getElementById(id);

const state = {
  menuOpen: false,
  data: null,
  modes: [],
  shop: {},
  shopOrder: [],
  owned: { owned: {}, equipped: {} },
  room: null,
  selfId: null,
  sort: 'kills',
  activeTab: 'play'
};

const RESOURCE = (typeof GetParentResourceName === 'function')
  ? GetParentResourceName()
  : 'battle-royale';

function post(name, payload) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(payload || {})
  }).catch(() => {});
}

function esc(value) {
  return String(value === undefined || value === null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ============================== VISIBILITE ============================== */

function showMenu(visible) {
  state.menuOpen = !!visible;
  $('app').classList.toggle('hidden', !state.menuOpen);
  if (!state.menuOpen) $('endScreen').classList.add('hidden');
}

function closeMenu() {
  // On ne ferme que ce qui est ouvert, sinon on relache le focus pour rien.
  if (!$('endScreen').classList.contains('hidden')) {
    $('endScreen').classList.add('hidden');
    showMenu(false);
    post('closeEnd');
    return;
  }
  if (!state.menuOpen) return;
  showMenu(false);
  post('close');
}

function resetAll() {
  showMenu(false);
  $('hud').classList.add('hidden');
  $('endScreen').classList.add('hidden');
  $('gasWarning').classList.add('hidden');
  $('planeHint').classList.add('hidden');
  $('lootToast').classList.add('hidden');
  $('toasts').innerHTML = '';
}

/* ================================ ONGLETS =============================== */

function setTab(tab) {
  state.activeTab = tab;
  document.querySelectorAll('.tab').forEach((el) => {
    el.classList.toggle('active', el.getAttribute('data-tab') === tab);
  });
  document.querySelectorAll('.panel').forEach((el) => {
    el.classList.toggle('active', el.id === `panel-${tab}`);
  });

  if (tab === 'rooms') post('requestRooms');
  if (tab === 'ranking') {
    post('requestLeaderboard', { sort: state.sort });
    post('requestHistory');
  }
}

/* ================================ ENTETE ================================ */

function renderStats(stats) {
  if (!stats) return;
  $('statGold').textContent = (stats.gold || 0).toLocaleString('fr-FR');
  $('statDiamonds').textContent = (stats.diamonds || 0).toLocaleString('fr-FR');
  $('statLevel').textContent = `Niv. ${stats.level || 1}`;
  const into = stats.xpInto || 0;
  const needed = stats.xpNeeded || 1000;
  $('statXp').textContent = `${into} / ${needed} XP`;
  $('xpFill').style.width = `${Math.min(100, (into / needed) * 100)}%`;

  $('sKills').textContent = stats.kills || 0;
  $('sWins').textContent = stats.wins || 0;
  $('sMatches').textContent = stats.matches || 0;
  const matches = stats.matches || 0;
  $('sRatio').textContent = matches > 0 ? ((stats.kills || 0) / matches).toFixed(2) : '0.00';
}

/* ================================= MODES ================================ */

function renderModes(modes) {
  state.modes = modes || [];
  const grid = $('modeGrid');
  const select = $('createMode');
  grid.innerHTML = '';
  select.innerHTML = '';

  state.modes.forEach((mode) => {
    const card = document.createElement('div');
    card.className = 'mode-card';
    card.innerHTML = `
      <h3>${esc(mode.label)}</h3>
      <p class="mode-sub">Equipes de ${mode.teamSize} &middot; ${mode.minPlayers} joueur(s) minimum</p>
      <button class="btn btn-primary" data-mode="${esc(mode.key)}">Partie rapide</button>
    `;
    card.querySelector('button').addEventListener('click', () => {
      post('quickMatch', { mode: mode.key });
      setTab('rooms');
    });
    grid.appendChild(card);

    const option = document.createElement('option');
    option.value = mode.key;
    option.textContent = mode.label;
    select.appendChild(option);
  });

  const n = state.modes.length;
  $('modeSummary').textContent = `${n} mode${n > 1 ? 's' : ''} disponible${n > 1 ? 's' : ''}`;
}

/* ============================== LISTE SALLES ============================= */

function renderRoomList(rooms) {
  const list = $('roomList');
  list.innerHTML = '';
  const empty = !rooms || rooms.length === 0;
  $('roomsEmpty').classList.toggle('hidden', !empty);
  if (empty) return;

  rooms.forEach((room) => {
    const row = document.createElement('div');
    row.className = 'room-row';
    row.innerHTML = `
      <span class="r-mode">${esc(room.mode)}</span>
      <span class="r-host">Hote : ${esc(room.hostName)}</span>
      ${room.planeDrop ? '<span class="r-tag">AVION</span>' : ''}
      <span class="r-count">${room.count}/${room.maxPlayers}</span>
      <button class="btn btn-primary">Rejoindre</button>
    `;
    row.querySelector('button').addEventListener('click', () => {
      post('joinRoom', { code: room.code });
    });
    list.appendChild(row);
  });
}

/* ================================= SALON ================================ */

function renderRoom(room) {
  state.room = room || null;
  const inRoom = !!room;
  $('roomsBrowser').classList.toggle('hidden', inRoom);
  $('roomLobby').classList.toggle('hidden', !inRoom);
  if (!inRoom) return;

  // `you` est envoye par le serveur pour chaque destinataire.
  if (typeof room.you !== 'undefined') state.selfId = room.you;

  $('roomCode').textContent = room.code;
  const visibility = room.visibility === 'private' ? 'Privee' : 'Publique';
  $('roomMeta').textContent =
    `${room.mode} - ${room.count}/${room.settings.maxPlayers} joueurs - ${visibility}`;

  // Compte a rebours
  const hasCountdown = typeof room.countdown === 'number' && room.countdown > 0;
  $('countdownBanner').classList.toggle('hidden', !hasCountdown);
  if (hasCountdown) $('countdownValue').textContent = room.countdown;

  // Joueurs
  const list = $('playerList');
  list.innerHTML = '';
  (room.players || []).forEach((player) => {
    const row = document.createElement('div');
    row.className = 'player-row';
    const badge = player.isHost
      ? '<span class="p-badge host">HOTE</span>'
      : (player.ready ? '<span class="p-badge ready">PRET</span>'
                      : '<span class="p-badge waiting">EN ATTENTE</span>');
    row.innerHTML = `
      <span class="p-name">${esc(player.name)}</span>
      <span class="p-lvl">Niv. ${player.level || 1}</span>
      ${badge}
    `;
    list.appendChild(row);

    // Un joueur pret voit son bouton bascule en "Plus pret".
    if (state.selfId !== null && player.id === state.selfId) {
      $('btnReady').textContent = player.ready ? 'Plus pret' : 'Je suis pret';
    }
  });

  // Seul l'hote peut modifier les reglages ou lancer la partie. Le serveur
  // revalide de toute facon chaque valeur recue.
  applyHostPermissions(state.selfId !== null && room.host === state.selfId);
  applySettings(room.settings);
}

function applyHostPermissions(isHost) {
  ['setMaxPlayers', 'setShrinkSpeed', 'setGasDamage', 'setPlaneDrop', 'setDrops',
    'setFriendlyFire', 'btnApplySettings', 'btnStartRoom'].forEach((id) => {
    $(id).disabled = !isHost;
  });
  $('hostHint').textContent = isHost ? '(vous etes hote)' : '(hote uniquement)';
}

function applySettings(settings) {
  if (!settings) return;
  $('setMaxPlayers').value = settings.maxPlayers;
  $('valMaxPlayers').textContent = settings.maxPlayers;
  $('setShrinkSpeed').value = settings.shrinkSpeed;
  $('valShrinkSpeed').textContent = `${Number(settings.shrinkSpeed).toFixed(2)}x`;
  $('setGasDamage').value = settings.gasDamage;
  $('valGasDamage').textContent = settings.gasDamage;
  $('setPlaneDrop').checked = !!settings.planeDrop;
  $('setDrops').checked = !!settings.dropsEnabled;
  $('setFriendlyFire').checked = !!settings.friendlyFire;
}

function collectSettings() {
  return {
    maxPlayers: parseInt($('setMaxPlayers').value, 10),
    shrinkSpeed: parseFloat($('setShrinkSpeed').value),
    gasDamage: parseInt($('setGasDamage').value, 10),
    planeDrop: $('setPlaneDrop').checked,
    dropsEnabled: $('setDrops').checked,
    friendlyFire: $('setFriendlyFire').checked
  };
}

/* ================================== CHAT ================================ */

function addChatLine(entry) {
  const log = $('chatLog');
  const line = document.createElement('div');
  line.className = `chat-line${entry.system ? ' system' : ''}`;
  line.innerHTML = entry.system
    ? esc(entry.message)
    : `<span class="c-name">${esc(entry.name)}</span> : ${esc(entry.message)}`;
  log.appendChild(line);
  while (log.children.length > 60) log.removeChild(log.firstChild);
  log.scrollTop = log.scrollHeight;
}

function renderChat(entries) {
  $('chatLog').innerHTML = '';
  (entries || []).forEach(addChatLine);
}

/* ============================ BOUTIQUE / SKINS =========================== */

const CATEGORY_LABELS = {
  Crates: 'Caisses',
  WeaponSkins: "Skins d'armes",
  PlayerTags: 'Titres de joueur'
};

function renderShop() {
  const container = $('shopCategories');
  container.innerHTML = '';

  (state.shopOrder || []).forEach((category) => {
    const items = state.shop[category] || [];
    if (items.length === 0) return;

    const block = document.createElement('div');
    block.className = 'shop-block';
    const title = document.createElement('h3');
    title.textContent = CATEGORY_LABELS[category] || category;
    block.appendChild(title);

    const grid = document.createElement('div');
    grid.className = 'item-grid';

    items.forEach((item) => {
      const isOwned = state.owned.owned[item.id] === true;
      const consumable = category === 'Crates';
      const card = document.createElement('div');
      card.className = 'item-card';
      const currency = item.currency === 'Diamonds' ? 'diamonds' : 'gold';
      const currencyLabel = item.currency === 'Diamonds' ? 'D' : 'G';
      card.innerHTML = `
        <div class="i-top">
          <div>
            <div class="i-name">${esc(item.name)}</div>
            ${item.weapon ? `<div class="i-weapon">${esc(weaponLabel(item.weapon))}</div>` : ''}
          </div>
          <div class="i-price ${currency}">${item.price} ${currencyLabel}</div>
        </div>
        <span class="rarity ${esc(item.rarity || 'Common')}">${esc(item.rarity || 'Common')}</span>
        <button class="btn ${isOwned && !consumable ? '' : 'btn-primary'}"
          ${isOwned && !consumable ? 'disabled' : ''}>
          ${isOwned && !consumable ? 'Deja possede' : (consumable ? 'Ouvrir' : 'Acheter')}
        </button>
      `;
      card.querySelector('button').addEventListener('click', () => {
        post('purchase', { id: item.id });
      });
      grid.appendChild(card);
    });

    block.appendChild(grid);
    container.appendChild(block);
  });
}

function weaponLabel(weapon) {
  return String(weapon).replace(/^WEAPON_/, '').replace(/_/g, ' ');
}

function renderLoadout() {
  const grid = $('loadoutGrid');
  grid.innerHTML = '';
  const skins = (state.shop.WeaponSkins || []).filter((s) => state.owned.owned[s.id] === true);

  $('loadoutEmpty').classList.toggle('hidden', skins.length > 0);

  skins.forEach((skin) => {
    const equipped = state.owned.equipped[skin.id] === true;
    const card = document.createElement('div');
    card.className = 'item-card';
    card.innerHTML = `
      <div class="i-top">
        <div>
          <div class="i-name">${esc(skin.name)}</div>
          <div class="i-weapon">${esc(weaponLabel(skin.weapon))}</div>
        </div>
      </div>
      <span class="rarity ${esc(skin.rarity || 'Common')}">${esc(skin.rarity || 'Common')}</span>
      <button class="btn ${equipped ? 'btn-danger' : 'btn-primary'}">
        ${equipped ? 'Retirer' : 'Equiper'}
      </button>
    `;
    card.querySelector('button').addEventListener('click', () => {
      post('equipSkin', { id: skin.id, equipped: !equipped });
    });
    grid.appendChild(card);
  });
}

/* =============================== CLASSEMENT ============================== */

function renderLeaderboard(rows) {
  const table = $('leaderboard');
  table.innerHTML = `
    <div class="table-row head">
      <span>#</span><span>Joueur</span><span class="t-num">Elim.</span>
      <span class="t-num">Vict.</span><span class="t-num">Niveau</span>
    </div>
  `;
  (rows || []).forEach((row, index) => {
    const rank = index + 1;
    const el = document.createElement('div');
    el.className = `table-row${rank <= 3 ? ` top${rank}` : ''}`;
    el.innerHTML = `
      <span class="t-rank">${rank}</span>
      <span class="t-name">${esc(row.name)}</span>
      <span class="t-num">${row.kills || 0}</span>
      <span class="t-num">${row.wins || 0}</span>
      <span class="t-num">${row.level || 1}</span>
    `;
    table.appendChild(el);
  });
}

function renderHistory(rows) {
  const table = $('historyTable');
  table.innerHTML = '';
  const empty = !rows || rows.length === 0;
  $('historyEmpty').classList.toggle('hidden', !empty);
  if (empty) return;

  table.innerHTML = `
    <div class="table-row head">
      <span>#</span><span>Date</span><span class="t-num">Mode</span>
      <span class="t-num">Elim.</span><span class="t-num">Survie</span>
    </div>
  `;
  rows.forEach((row) => {
    const el = document.createElement('div');
    el.className = 'table-row';
    el.innerHTML = `
      <span class="t-rank ${row.won ? 'win' : ''}">${row.placement}</span>
      <span class="t-name">${esc(row.playedAt || '')}</span>
      <span class="t-num">${esc(row.mode)}</span>
      <span class="t-num">${row.kills || 0}</span>
      <span class="t-num">${formatTime(row.survived || 0)}</span>
    `;
    table.appendChild(el);
  });
}

function formatTime(seconds) {
  const total = Math.max(0, Math.floor(seconds));
  const m = String(Math.floor(total / 60)).padStart(2, '0');
  const s = String(total % 60).padStart(2, '0');
  return `${m}:${s}`;
}

/* =================================== HUD ================================ */

let lootTimer = null;

function updateHud(msg) {
  $('hudElapsed').textContent = msg.elapsed || '00:00';
  $('hudRadius').textContent = `Zone : ${msg.radius || 0} m`;
  $('hudPhase').textContent = msg.phase
    ? `Phase ${msg.phase}/${msg.totalPhases || 0}`
    : 'Zone en attente';
  $('hudZoneTimer').textContent = msg.remainingLabel || '00:00';

  const initial = msg.initialRadius || 1;
  $('hudZoneFill').style.width = `${Math.max(0, Math.min(100, ((msg.radius || 0) / initial) * 100))}%`;

  const shrinking = msg.state === 'shrinking' || msg.state === 'closed';
  $('hudZonePill').classList.toggle('shrinking', shrinking);
  $('hudZoneState').textContent = shrinking ? 'GAZ EN COURS' : 'PROCHAINE ZONE';
  $('planeHint').classList.toggle('hidden', !msg.inPlane);
}

function showLootToast(tier, weapon) {
  const toast = $('lootToast');
  toast.textContent = `${tier} - ${weaponLabel(weapon || '')}`.trim();
  toast.classList.remove('hidden');
  if (lootTimer) clearTimeout(lootTimer);
  lootTimer = setTimeout(() => toast.classList.add('hidden'), 2600);
}

/* ============================== FIN DE PARTIE =========================== */

function showEnd(result) {
  if (!result) return;
  const badge = $('endBadge');
  badge.textContent = `#${result.placement || '-'}`;
  badge.classList.toggle('defeat', !result.won);
  const title = $('endTitle');
  title.textContent = result.won ? 'VICTOIRE ROYALE' : 'ELIMINE';
  title.classList.toggle('defeat', !result.won);
  const place = result.placement === 1 ? '1er' : `${result.placement}e`;
  $('endSubtitle').textContent =
    `Vous finissez ${place} sur ${result.totalPlayers} joueurs`;
  $('endKills').textContent = result.kills || 0;
  $('endTime').textContent = formatTime(result.survived || 0);
  $('endMode').textContent = result.mode || '-';

  const rewards = $('endRewards');
  rewards.innerHTML = '';
  const r = result.rewards || {};
  if (r.gold) rewards.innerHTML += `<span class="reward-chip gold">+${r.gold} Or</span>`;
  if (r.xp) rewards.innerHTML += `<span class="reward-chip xp">+${r.xp} XP</span>`;
  if (r.diamonds) {
    rewards.innerHTML +=
      `<span class="reward-chip diamond">+${r.diamonds} Diamant${r.diamonds > 1 ? 's' : ''}</span>`;
  }
  if (r.levelUp) rewards.innerHTML += `<span class="reward-chip levelup">Niveau ${r.level} atteint</span>`;

  // L'ecran de fin passe devant le menu principal.
  $('app').classList.add('hidden');
  $('endScreen').classList.remove('hidden');
}

/* ================================= TOASTS =============================== */

function toast(message) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = message;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

/* ============================ MESSAGES DU CLIENT ======================== */

window.addEventListener('message', (event) => {
  const msg = event.data || {};
  switch (msg.action) {
    case 'reset':
      resetAll();
      break;

    case 'setData': {
      const data = msg.data || {};
      state.data = data;
      state.shop = data.shop || {};
      state.shopOrder = data.shopOrder || [];
      state.owned = data.owned || { owned: {}, equipped: {} };
      renderStats(data.stats);
      renderModes(data.modes);
      renderShop();
      renderLoadout();
      renderRoomList(data.rooms);
      renderRoom(data.room);
      if (data.room) {
        renderChat(data.room.chat);
        setTab('rooms');
      } else {
        setTab('play');
      }
      break;
    }

    case 'openMenu':
      showMenu(true);
      break;

    case 'closeMenu':
      showMenu(false);
      break;

    case 'updateStats':
      renderStats(msg.stats);
      break;

    case 'updateOwned':
      state.owned = msg.owned || { owned: {}, equipped: {} };
      renderShop();
      renderLoadout();
      break;

    case 'roomList':
      renderRoomList(msg.rooms);
      break;

    case 'roomUpdate':
      renderRoom(msg.room);
      if (msg.room && msg.room.chat) renderChat(msg.room.chat);
      break;

    case 'roomLeft':
      renderRoom(null);
      renderChat([]);
      post('requestRooms');
      break;

    case 'chatMessage':
      if (msg.entry) addChatLine(msg.entry);
      break;

    case 'leaderboard':
      state.sort = msg.sort || 'kills';
      document.querySelectorAll('.sort').forEach((el) => {
        el.classList.toggle('active', el.getAttribute('data-sort') === state.sort);
      });
      renderLeaderboard(msg.rows);
      break;

    case 'history':
      renderHistory(msg.rows);
      break;

    case 'notify':
      toast(msg.message);
      break;

    case 'matchStart':
      showMenu(false);
      $('endScreen').classList.add('hidden');
      break;

    case 'showHud':
      $('hud').classList.toggle('hidden', !msg.value);
      if (!msg.value) {
        $('gasWarning').classList.add('hidden');
        $('planeHint').classList.add('hidden');
      }
      break;

    case 'updateHud':
      updateHud(msg);
      break;

    case 'updateAlive':
      $('hudAlive').textContent = msg.alive || 0;
      $('hudKills').textContent = msg.kills || 0;
      break;

    case 'updateZone':
      $('hudZoneTimer').textContent = formatTime(msg.remaining || 0);
      break;

    case 'inGas':
      $('gasWarning').classList.toggle('hidden', !msg.value);
      break;

    case 'planeState':
      $('planeHint').classList.toggle('hidden', msg.state !== 'flying');
      break;

    case 'lootPopup':
      showLootToast(msg.tier, msg.weapon);
      break;

    case 'matchEnd':
      showEnd(msg.result);
      break;

    case 'showEndScreen':
      $('app').classList.add('hidden');
      $('endScreen').classList.remove('hidden');
      break;

    default:
      break;
  }
});

/* ================================ ECOUTEURS ============================= */

document.addEventListener('DOMContentLoaded', () => {
  // Rien n'est visible au demarrage : pas d'ecran noir residuel.
  resetAll();

  document.querySelectorAll('.tab').forEach((el) => {
    el.addEventListener('click', () => setTab(el.getAttribute('data-tab')));
  });

  $('btnClose').addEventListener('click', closeMenu);
  $('btnEndClose').addEventListener('click', () => {
    $('endScreen').classList.add('hidden');
    showMenu(false);
    post('closeEnd');
  });

  $('btnRefreshRooms').addEventListener('click', () => post('requestRooms'));

  $('btnJoinCode').addEventListener('click', () => {
    const code = ($('joinCode').value || '').trim().toUpperCase();
    if (code.length >= 3) {
      post('joinRoom', { code });
      $('joinCode').value = '';
    }
  });

  $('joinCode').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      $('btnJoinCode').click();
    }
  });

  $('btnCreateRoom').addEventListener('click', () => {
    const mode = $('createMode').value;
    // Without this the click would post mode:"" and the server would reject it
    // silently, which looks exactly like a dead button.
    if (!mode) {
      toast('Aucun mode disponible - rouvrez le menu.');
      return;
    }
    post('createRoom', {
      mode,
      visibility: $('createVisibility').value,
      settings: collectSettings()
    });
  });

  $('btnLeaveRoom').addEventListener('click', () => post('leaveRoom'));
  $('btnReady').addEventListener('click', () => post('toggleReady'));
  $('btnStartRoom').addEventListener('click', () => post('startRoom'));
  $('btnApplySettings').addEventListener('click', () => {
    post('updateSettings', { settings: collectSettings() });
  });

  // Retour visuel immediat des curseurs, meme avant validation serveur.
  $('setMaxPlayers').addEventListener('input', (e) => {
    $('valMaxPlayers').textContent = e.target.value;
  });
  $('setShrinkSpeed').addEventListener('input', (e) => {
    $('valShrinkSpeed').textContent = `${Number(e.target.value).toFixed(2)}x`;
  });
  $('setGasDamage').addEventListener('input', (e) => {
    $('valGasDamage').textContent = e.target.value;
  });

  $('chatForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const input = $('chatInput');
    const message = (input.value || '').trim();
    if (!message) return;
    post('sendChat', { message });
    input.value = '';
  });

  document.querySelectorAll('.sort').forEach((el) => {
    el.addEventListener('click', () => {
      post('requestLeaderboard', { sort: el.getAttribute('data-sort') });
    });
  });
});

/* ESC doit etre capture ICI : cote Lua, IsControlJustReleased ne se declenche
   jamais tant que la frame NUI garde le focus clavier. On ecoute keydown ET
   keyup pour ne rien manquer selon la maniere dont le focus est relache. */
function handleEscape(event) {
  if (event.key !== 'Escape' && event.keyCode !== 27) return;
  event.preventDefault();
  // On ne vole pas la touche si le joueur est en train d'ecrire dans le chat.
  if (document.activeElement === $('chatInput') || document.activeElement === $('joinCode')) {
    document.activeElement.blur();
    return;
  }
  closeMenu();
}

document.addEventListener('keydown', handleEscape);
document.addEventListener('keyup', handleEscape);
