# Battle Royale — v3.0.3

Ressource FiveM autonome : salles personnalisées, chat de lobby, saut en avion avec
parachute, zone de gaz dynamique multi-phases, loot d'armes réelles, boutique de skins,
classements et historique de parties persistants.

Aucune dépendance externe obligatoire, aucun asset à télécharger (pas de `bg.jpg`, pas de
CDN, pas de police externe). Fonctionne en standalone, avec détection automatique de
ESX / QBCore et de oxmysql.

---

## Installation

> **IMPORTANT — supprimer l'ancien dossier d'abord.**
> Ne copiez pas la v3 par-dessus une ancienne version : l'ancien `fxmanifest.lua`
> et les anciens fichiers survivent et le serveur charge un mélange des deux.
> Le symptôme est ce genre de lignes dans la console :
>
> ```
> could not find client_script `client/lobby.lua`
> could not find server_script `server/events.lua`
> could not find file `ui/bg.jpg`
> ```
>
> Ces trois fichiers n'existent **pas** en v3 : s'ils apparaissent, c'est l'ancien
> manifeste qui tourne encore.
>
> ```bash
> # dans resources/
> rm -rf battle-royale          # ou renommer en battle-royale_old
> # puis extraire le zip v3 ici
> ```

1. Copier le dossier `battle-royale` dans `resources/` de votre serveur.
2. Ajouter dans `server.cfg` :

```cfg
ensure oxmysql          # optionnel mais recommandé (persistance)
ensure battle-royale
```

3. **Base de données** — rien à faire dans le cas normal. Au démarrage la ressource
   crée elle-même ses tables et ajoute les colonnes manquantes, puis affiche :

```
[battle-royale] oxmysql detected, schema OK - stats are persistent.
```

Trois tables sont utilisées : `br_players` (statistiques, or, diamants, XP),
`br_inventory` (objets achetés et skins équipés), `br_match_history` (historique).

Si la création automatique échoue (utilisateur MySQL sans droit `CREATE`/`ALTER`,
par exemple), importez les fichiers à la main :

```bash
# création initiale
mysql -u root -p votre_base < resources/battle-royale/database.sql
# réparation d'une base d'une ancienne version (Unknown column ...)
mysql -u root -p votre_base < resources/battle-royale/migration.sql
```

> Sans oxmysql la ressource démarre quand même : tout passe en mémoire et les données
> sont perdues au redémarrage. Un message le signale dans la console au démarrage.

4. Redémarrer le serveur (ou `refresh` puis `ensure battle-royale`).

### Droit admin

La commande `/brgive` est protégée par l'ace `command.brgive` :

```cfg
add_ace group.admin command.brgive allow
```

---

## Commandes

| Commande | Côté | Description |
| --- | --- | --- |
| `/br` | joueur | Ouvre le menu Battle Royale |
| `/battleroyale` | joueur | Alias de `/br` |
| `/brquit` | joueur | Abandonne la partie en cours et rend le contrôle |
| `/brgive <id> <Gold\|Diamonds> <montant>` | admin / console | Crédite un joueur |

Fermeture du menu : touche **Échap** ou le bouton **✕** en haut à droite. Le focus NUI
est relâché dans les deux cas, et un thread de surveillance côté client force le
déverrouillage si le menu se retrouve fermé sans avoir rendu le focus.

---

## Fonctionnalités

### Salles personnalisées
- Salles **publiques** (visibles dans l'onglet SALLES) ou **privées** (accès par code).
- Code de salle à 5 caractères, alphabet sans ambiguïté (pas de `0`/`O`, `1`/`I`).
- L'hôte règle en direct : nombre de joueurs max, vitesse de rétrécissement de la zone,
  dégâts du gaz, saut en avion oui/non, caisses de loot oui/non, tir allié oui/non.
- Système « je suis prêt » + compte à rebours automatique (20 s par défaut) dès que le
  minimum de joueurs est prêt. L'hôte peut aussi lancer manuellement.
- **Partie rapide** : rejoint une salle publique compatible ou en crée une.

### Chat de lobby
Chat par salle, 40 messages d'historique, 120 caractères max, anti-spam 1 s, messages
système (arrivées, départs, changements de réglages, compte à rebours).

### Saut en avion + parachute
Un Titan non-networké suit une trajectoire aléatoire traversant le centre de la carte à
400 m d'altitude. Le joueur saute avec **Espace**, ou est éjecté automatiquement après
40 s. `TaskSkyDive` puis parachute (`GADGET_PARACHUTE`) donné automatiquement, avec
ouverture auto sous 120 m si le joueur ne l'ouvre pas.

### Zone de gaz dynamique
7 phases configurables (1400 → 1000 → 700 → 450 → 250 → 120 → 40 → 0 m), chacune avec
son temps d'attente, sa durée de rétrécissement et ses dégâts (2 → 25 par tick). Le
nouveau centre dérive de façon aléatoire mais contrainte. Deux blips sur la carte : la
zone actuelle et la prochaine. Les dégâts ne peuvent jamais tuer par valeur négative
(santé bornée) et un avertissement s'affiche 10 s avant chaque rétrécissement.

### Loot et armes réelles
10 caisses positionnées sur la carte, prop `prop_box_ammo04a`, interaction **[E]**.
Chaque caisse ne peut être ouverte qu'une fois par partie, et la distance est vérifiée
**côté serveur** (6 m). Quatre raretés : Common 55 % / Rare 27 % / Epic 13 % /
Legendary 5 %. Les armes sont réellement données (`GiveWeaponToPed`) avec munitions.

### Boutique et skins
- **Caisses** : ouvrent un skin non encore possédé, remboursées si tout est déjà obtenu.
- **Skins d'armes** : appliqués automatiquement (teinte + composants) à l'arme
  correspondante lorsqu'elle est ramassée.
- **Tags joueur** : cosmétiques affichés dans le classement.
- Deux monnaies : **Or** (gagné en jouant) et **Diamants** (récompense de victoire).

### Classement et historique
Classement serveur triable par **éliminations / victoires / XP** (top 15) et historique
des dernières parties du joueur (mode, placement, éliminations, temps de survie).
Récompenses : 50 or + 25 XP par élimination, 500 or + 250 XP + 1 diamant par victoire,
25 or + 10 XP de participation, 1000 XP par niveau.

---

## Guide de configuration

Tout se règle dans `config.lua`.

| Section | Rôle |
| --- | --- |
| `Config.Debug` / `DebugMinPlayers` | Mode test : permet de lancer une partie seul. **Mettre `Debug = false` en production.** |
| `Config.Command` / `AltCommand` | Noms des commandes d'ouverture du menu |
| `Config.Locale` | `'FR'` ou `'EN'` pour les textes en jeu |
| `Config.GameModes` | Solo / Duo / Trio / Squad : taille d'équipe, minimum et maximum de joueurs |
| `Config.Rooms` | Longueur du code, nombre max de salles, bornes des réglages hôte, chat, compte à rebours |
| `Config.Map` | Centre de la zone de jeu et rayon initial |
| `Config.SpawnPoints` | Points d'atterrissage au sol (utilisés si le saut en avion est désactivé) |
| `Config.PlaneDrop` | Modèle d'avion, altitude, vitesse, longueur de trajectoire, éjection forcée, parachute |
| `Config.ZonePhases` | Les 7 phases : rayon, attente, durée de rétrécissement, dégâts |
| `Config.Zone` | Fréquence de tick, dérive du centre, transparence des blips, avertissement |
| `Config.LootTiers` | Raretés, poids de tirage et listes d'armes (`WEAPON_*`) |
| `Config.LootCrates` | Positions des 10 caisses + `CrateModel` |
| `Config.ShopItems` / `ShopOrder` | Contenu et ordre d'affichage de la boutique |
| `Config.Rewards` | Or / XP / diamants gagnés, XP par niveau |
| `Config.Leaderboard` | Nombre de lignes du classement |
| `Config.Languages` | Textes EN / FR |

**Ajouter une arme au loot** : ajouter son nom `WEAPON_*` dans la liste `weapons` de la
rareté voulue dans `Config.LootTiers`.

**Ajouter un skin** : ajouter une entrée dans `Config.ShopItems.WeaponSkins` avec
`weapon` correspondant à une arme présente dans `Config.LootTiers`, plus `tint` et
éventuellement `components`.

---

## Ce qui change par rapport à la v2.0.0

| Domaine | v2.0.0 | v3.0.0 |
| --- | --- | --- |
| Matchmaking | File d'attente unique par mode | Salles publiques/privées avec code, réglages hôte, système « prêt », partie rapide, plus la partie rapide automatique |
| Chat | Aucun | Chat de lobby par salle avec historique, anti-spam et messages système |
| Départ de partie | Téléportation directe au sol | Avion + saut + parachute, trajectoire aléatoire, éjection forcée |
| Zone | Rétrécissement simple | 7 phases configurables, centre qui dérive, avertissement, blip de la prochaine zone |
| Loot | Récompenses symboliques | Armes réelles données au joueur, 4 raretés pondérées, vérification de distance serveur |
| Boutique | Absente | Caisses, skins d'armes appliqués en jeu, tags joueur, deux monnaies |
| Persistance | Aucune | oxmysql : statistiques, inventaire, historique, classement (avec repli mémoire) |
| Interface | Menu simple | 5 onglets (Jouer / Salles / Équipement / Boutique / Classement), HUD de partie, écran de fin |
| Base de données | — | `database.sql` : `br_players`, `br_inventory`, `br_match_history` |

Tous les correctifs de la v2.0.0 sont conservés : menu invisible au démarrage, Échap
capté côté NUI (l'input Lua ne se déclenche pas quand la NUI a le focus clavier),
focus NUI toujours relâché, aucun écran noir permanent, aucun asset externe manquant,
détection oxmysql à l'exécution plutôt qu'un `@oxmysql/lib/MySQL.lua` en dur.

---

## Structure

```
battle-royale/
├── fxmanifest.lua
├── config.lua
├── database.sql        # création des tables
├── migration.sql       # réparation d'une base d'une ancienne version
├── README.md
├── shared/
│   └── constants.lua
├── server/
│   ├── main.lua        # état global, menu, déconnexions
│   ├── database.lua    # oxmysql + repli mémoire
│   ├── stats.lua       # classement, historique, récompenses
│   ├── rooms.lua       # salles, chat, compte à rebours
│   ├── game.lua        # match, zone, éliminations, victoire
│   └── loot.lua        # caisses, boutique, skins, /brgive
├── client/
│   ├── main.lua        # menu, focus NUI, commandes
│   ├── rooms.lua       # relais salles/chat/classement
│   ├── loadout.lua     # armes et skins
│   ├── plane.lua       # avion, saut, parachute
│   ├── game.lua        # partie, zone, caisses, mort
│   ├── hud.lua         # HUD de partie
│   └── ui.lua          # callbacks NUI, /brquit
└── ui/
    ├── index.html
    ├── style.css
    └── script.js
```

---

## Dépannage

| Symptôme | Cause / solution |
| --- | --- |
| Le menu ne s'ouvre pas | Vérifier que la ressource est `ensure` **après** oxmysql et regarder la console F8 |
| Souris bloquée après fermeture | Utiliser `/brquit`, le thread de surveillance rend le focus dans la seconde |
| `Unknown column 'equipped' in 'field list'` | Une table `br_inventory` d'une ancienne version existe sans les colonnes v3. La v3 la répare seule au démarrage ; si l'utilisateur MySQL n'a pas le droit `ALTER`, lancer `migration.sql`, ou en dernier recours `DROP TABLE br_inventory;` puis redémarrer |
| `attempt to call a nil value (global 'BuildRoomList')` (ou `StartMatchFromRoom`, `BuildLeaderboard`...) | Le fichier qui définit cette fonction n'est pas chargé, donc `fxmanifest.lua` est celui d'une ancienne version. La console affiche au démarrage la liste exacte des fichiers manquants. Remplacer le dossier entier |
| Avertissements sur `client/lobby.lua`, `server/events.lua`, `ui/bg.jpg` | L'ancien dossier n'a pas été supprimé : l'ancien `fxmanifest.lua` est toujours chargé. Supprimer `resources/battle-royale` entièrement et réextraire le zip v3 |
| Statistiques remises à zéro au redémarrage | oxmysql absent, ou message `schema unusable` dans la console (voir les deux lignes ci-dessus) |
| Impossible de lancer une partie seul | `Config.Debug = true` et `Config.DebugMinPlayers = 1` |
| Aucune arme après une caisse | Vérifier que les noms `WEAPON_*` de `Config.LootTiers` sont valides |
