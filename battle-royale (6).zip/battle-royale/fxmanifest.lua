fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'YourName'
description 'Battle Royale - rooms, plane drop, dynamic gas zone, leaderboards'
version '3.0.5'

shared_scripts {
    'config.lua',
    'shared/constants.lua'
}

client_scripts {
    'client/main.lua',
    'client/rooms.lua',
    'client/loadout.lua',
    'client/plane.lua',
    'client/game.lua',
    'client/hud.lua',
    'client/ui.lua'
}

-- oxmysql is detected at RUNTIME (see server/database.lua) instead of being
-- required here. A hard '@oxmysql/lib/MySQL.lua' import makes the entire
-- resource fail to start when the dependency is missing or starts later.
server_scripts {
    'server/main.lua',
    'server/database.lua',
    'server/stats.lua',
    'server/rooms.lua',
    'server/game.lua',
    'server/loot.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js'
}
