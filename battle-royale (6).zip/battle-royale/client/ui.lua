-- NUI callbacks. Every callback replies with cb() so the interface never waits
-- on a pending promise.

local function ok(cb) cb({ ok = true }) end

-- Sentinel read by /brdiag (see client/main.lua).
function BR.UiModuleLoaded() return true end

RegisterNUICallback('close', function(_, cb)
    BR.SetMenuOpen(false)
    ok(cb)
end)

-- The summary screen closes without reopening the lobby panel.
RegisterNUICallback('closeEnd', function(_, cb)
    BR.SetMenuOpen(false)
    ok(cb)
end)

RegisterNUICallback('requestRooms', function(_, cb)
    BR.ExpectServerResponse('Actualiser les salles')
    TriggerServerEvent('br:server:requestRooms')
    ok(cb)
end)

RegisterNUICallback('createRoom', function(data, cb)
    BR.ExpectServerResponse('Creer la salle')
    TriggerServerEvent('br:server:createRoom', {
        mode = data and data.mode,
        visibility = data and data.visibility,
        settings = data and data.settings
    })
    ok(cb)
end)

RegisterNUICallback('joinRoom', function(data, cb)
    if data and type(data.code) == 'string' then
        BR.ExpectServerResponse('Rejoindre la salle')
        TriggerServerEvent('br:server:joinRoom', data.code)
    end
    ok(cb)
end)

RegisterNUICallback('leaveRoom', function(_, cb)
    TriggerServerEvent('br:server:leaveRoom')
    ok(cb)
end)

RegisterNUICallback('quickMatch', function(data, cb)
    if data and type(data.mode) == 'string' then
        BR.ExpectServerResponse('Partie rapide')
        TriggerServerEvent('br:server:quickMatch', data.mode)
    end
    ok(cb)
end)

RegisterNUICallback('toggleReady', function(_, cb)
    BR.ExpectServerResponse('Pret')
    TriggerServerEvent('br:server:toggleReady')
    ok(cb)
end)

RegisterNUICallback('updateSettings', function(data, cb)
    TriggerServerEvent('br:server:updateRoomSettings', data or {})
    ok(cb)
end)

RegisterNUICallback('startRoom', function(_, cb)
    BR.ExpectServerResponse('Lancer la partie')
    TriggerServerEvent('br:server:startRoom')
    ok(cb)
end)

RegisterNUICallback('sendChat', function(data, cb)
    if data and type(data.message) == 'string' and data.message ~= '' then
        TriggerServerEvent('br:server:sendChat', data.message)
    end
    ok(cb)
end)

RegisterNUICallback('requestLeaderboard', function(data, cb)
    TriggerServerEvent('br:server:requestLeaderboard', (data and data.sort) or 'kills')
    ok(cb)
end)

RegisterNUICallback('requestHistory', function(_, cb)
    TriggerServerEvent('br:server:requestHistory')
    ok(cb)
end)

RegisterNUICallback('purchase', function(data, cb)
    if data and type(data.id) == 'string' then
        TriggerServerEvent('br:server:purchaseItem', data.id)
    end
    ok(cb)
end)

RegisterNUICallback('equipSkin', function(data, cb)
    if data and type(data.id) == 'string' then
        TriggerServerEvent('br:server:equipSkin', data.id, data.equipped and true or false)
    end
    ok(cb)
end)

-- Abandon is a command, not a button: the HUD is deliberately
-- pointer-events:none so it can never intercept clicks during a match.
RegisterCommand('brquit', function()
    if not BR.inGame then
        BR.Notify(BRLocale('not_in_room'))
        return
    end
    TriggerServerEvent('br:server:abandonMatch')
    BR.SetMenuOpen(false)
end, false)
