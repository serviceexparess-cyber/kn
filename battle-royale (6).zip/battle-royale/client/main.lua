-- Shared client state. Declared GLOBAL on purpose: client/ui.lua, game.lua,
-- plane.lua and hud.lua all read it. A `local` here would read as nil there.
BR = {
    menuOpen = false,
    hudActive = false,
    inGame = false,
    inPlane = false,
    gameId = nil,
    mode = nil,
    zone = nil,
    skins = {},
    owned = { owned = {}, equipped = {} },
    stats = {},
    room = nil,
    dropsEnabled = true,
    crates = {},
    lootedCrates = {}
}

CreateThread(function()
    if GetResourceState('qb-core') == 'started' then
        BR.QBCore = exports['qb-core']:GetCoreObject()
    elseif GetResourceState('es_extended') == 'started' then
        BR.ESX = exports['es_extended']:getSharedObject()
    end
end)

-- ============================== NUI FOCUS =================================

-- The single place that toggles NUI focus. Everything else calls this, so focus
-- can never be left on by a path that forgot to release it.
function BR.SetMenuOpen(open)
    BR.menuOpen = open and true or false
    SetNuiFocus(BR.menuOpen, BR.menuOpen)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = BR.menuOpen and 'openMenu' or 'closeMenu' })
end

function BR.CloseMenu()
    if not BR.menuOpen then return end
    BR.SetMenuOpen(false)
end

-- Watchdog: if focus is somehow held while the menu is closed (script error,
-- resource restart, race between events), release it. Without this the player
-- is stuck with a locked keyboard and no visible interface.
CreateThread(function()
    while true do
        Wait(500)
        if not BR.menuOpen and IsNuiFocused() then
            SetNuiFocus(false, false)
            SetNuiFocusKeepInput(false)
        end
    end
end)

-- ESC is also caught in JS (see ui/script.js): IsControlJustReleased never
-- fires while the NUI frame holds keyboard focus. These are the fallbacks for
-- when focus was already lost.
CreateThread(function()
    while true do
        Wait(0)
        if BR.menuOpen then
            if IsControlJustReleased(0, 200) or IsControlJustReleased(0, 202) then
                BR.CloseMenu()
            end
        else
            Wait(200)
        end
    end
end)

-- ============================== NOTIFICATIONS =============================

function BR.Notify(message)
    if not message then return end
    SendNUIMessage({ action = 'notify', message = message })
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, true)
end

-- ====================== SERVER RESPONSE WATCHDOG ==========================
-- FiveM drops a TriggerServerEvent silently when the server never registered
-- the event (typically because fxmanifest.lua does not list the file that
-- registers it). The button then looks dead with zero errors anywhere. This
-- turns that silence into an explicit message in-game and in the console.

BR.pending = nil

function BR.ExpectServerResponse(label)
    local token = { label = label }
    BR.pending = token
    CreateThread(function()
        Wait(4000)
        if BR.pending ~= token then return end
        BR.pending = nil
        BR.Notify("Le serveur n'a pas repondu (" .. label .. ").")
        print("[battle-royale] --------------------------------------------------")
        print("[battle-royale] Aucune reponse du serveur pour l'action: " .. label)
        print("[battle-royale] L'evenement serveur n'est pas enregistre. Le fichier")
        print("[battle-royale] server/rooms.lua ou server/game.lua n'est PAS charge.")
        print("[battle-royale] Cause quasi certaine: fxmanifest.lua est celui d'une")
        print("[battle-royale] ancienne version. Tape /brdiag pour la liste exacte.")
        print("[battle-royale] --------------------------------------------------")
    end)
end

function BR.ServerResponded()
    BR.pending = nil
end

RegisterNetEvent('br:client:notify', function(message)
    BR.ServerResponded()
    BR.Notify(message)
end)

-- ================================ COMMANDS ================================

local function openBattleRoyale()
    if BR.inGame then
        BR.Notify(BRLocale('in_game'))
        return
    end
    TriggerServerEvent('br:server:requestMenu')
end

RegisterCommand(Config.Command, openBattleRoyale, false)
if Config.AltCommand and Config.AltCommand ~= Config.Command then
    RegisterCommand(Config.AltCommand, openBattleRoyale, false)
end

RegisterNetEvent('br:client:openMenu', function(data)
    if BR.inGame then return end
    BR.stats = data.stats or {}
    BR.owned = data.owned or { owned = {}, equipped = {} }
    BR.room = data.room

    SendNUIMessage({ action = 'setData', data = data })
    BR.SetMenuOpen(true)
end)

RegisterNetEvent('br:client:updateStats', function(stats)
    BR.stats = stats or {}
    SendNUIMessage({ action = 'updateStats', stats = BR.stats })
end)

-- ============================== BOOT / RESET ==============================

-- Nothing may be visible and no focus may be held when the resource starts.
-- This is what prevents the "permanent black screen with a locked keyboard"
-- after a restart mid-session.
AddEventHandler('onClientResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    BR.menuOpen = false
    BR.hudActive = false
    BR.inGame = false
    BR.inPlane = false
    BR.gameId = nil
    BR.zone = nil
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'reset' })
    BRDebug('client ready - use /' .. Config.Command)
end)

AddEventHandler('onClientResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    ClearFocus()
    ResetPlayerStamina(PlayerId())
end)

-- ============================== /brdiag ===================================
-- Self-diagnosis. Prints, in the F8 console, exactly which client files are
-- loaded, then asks the server to print the same for its own side. Use this
-- first whenever a button "does nothing": a missing file here means
-- fxmanifest.lua is not the v3 one.

RegisterCommand('brdiag', function()
    local modules = {
        { file = 'client/rooms.lua',   fn = BR.RoomsModuleLoaded },
        { file = 'client/loadout.lua', fn = BR.GiveWeapon        },
        { file = 'client/plane.lua',   fn = BR.StartPlaneDrop    },
        { file = 'client/game.lua',    fn = BR.ExitGame          },
        { file = 'client/hud.lua',     fn = BR.StartHUD          },
        { file = 'client/ui.lua',      fn = BR.UiModuleLoaded    }
    }

    print('[brdiag] ---------------- CLIENT ----------------')
    print(('[brdiag] resource version : %s')
        :format(GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '?'))
    print(('[brdiag] locale=%s debug=%s modes=%d')
        :format(tostring(Config.Locale), tostring(Config.Debug), #Config.ModeOrder))

    local missing = 0
    for _, entry in ipairs(modules) do
        local loaded = type(entry.fn) == 'function'
        if not loaded then missing = missing + 1 end
        print(('[brdiag] %-22s %s'):format(entry.file, loaded and 'OK' or '*** NOT LOADED ***'))
    end

    print(('[brdiag] menuOpen=%s nuiFocused=%s inGame=%s room=%s')
        :format(tostring(BR.menuOpen), tostring(IsNuiFocused()),
                tostring(BR.inGame), BR.room and BR.room.code or 'none'))

    if missing > 0 then
        print(('[brdiag] %d CLIENT FILE(S) MISSING -> your fxmanifest.lua is from an')
            :format(missing))
        print('[brdiag] older version. Replace resources/battle-royale entirely.')
    end

    TriggerServerEvent('br:server:diag')
end, false)
