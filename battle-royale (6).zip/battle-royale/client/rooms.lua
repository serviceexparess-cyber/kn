-- Room list, lobby state and chat relayed to the interface.

-- Sentinel read by /brdiag: this file only registers events, so it needs an
-- explicit marker to prove fxmanifest.lua actually loads it.
function BR.RoomsModuleLoaded() return true end

RegisterNetEvent('br:client:roomList', function(rooms)
    BR.ServerResponded()
    SendNUIMessage({ action = 'roomList', rooms = rooms or {} })
end)

RegisterNetEvent('br:client:roomUpdate', function(room)
    BR.ServerResponded()
    BR.room = room
    SendNUIMessage({ action = 'roomUpdate', room = room })
end)

RegisterNetEvent('br:client:roomLeft', function()
    BR.ServerResponded()
    BR.room = nil
    SendNUIMessage({ action = 'roomLeft' })
end)

RegisterNetEvent('br:client:chatMessage', function(entry)
    BR.ServerResponded()
    SendNUIMessage({ action = 'chatMessage', entry = entry })
end)

RegisterNetEvent('br:client:leaderboard', function(data)
    SendNUIMessage({ action = 'leaderboard', sort = data.sort, rows = data.rows or {} })
end)

RegisterNetEvent('br:client:history', function(rows)
    SendNUIMessage({ action = 'history', rows = rows or {} })
end)

-- ================================ INVITES ==================================

-- /brinvite <id> : invite a specific player (their server id, shown with
-- /brid or the F8 console) straight into your current room.
RegisterCommand('brinvite', function(_, args)
    local targetId = args and args[1]
    if not targetId then
        BR.Notify('Usage: /brinvite [id du joueur]')
        return
    end
    TriggerServerEvent('br:server:invitePlayer', targetId)
end, false)

-- /brjoin : accept the most recent pending invite.
RegisterCommand('brjoin', function()
    TriggerServerEvent('br:server:acceptInvite')
end, false)

RegisterNetEvent('br:client:roomInvite', function(data)
    if not data then return end
    BR.Notify(('%s t\'invite dans son salon (code %s). Tape /brjoin pour rejoindre.')
        :format(data.fromName or '?', data.code or '?'))
    SendNUIMessage({ action = 'roomInvite', code = data.code, fromName = data.fromName })
end)
