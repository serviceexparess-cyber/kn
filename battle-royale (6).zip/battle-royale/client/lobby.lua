local inQueue = false
local queueData = nil

RegisterNetEvent('br:client:showLobby')
AddEventHandler('br:client:showLobby', function()
    SendNUIMessage({ action = 'openLobby' })
    SetNuiFocus(true, true)
end)

RegisterNUICallback('joinQueue', function(data, cb)
    local mode = data.mode
    if not mode or not Config.GameModes[mode] then cb('error') return end
    TriggerServerEvent('br:server:joinQueue', mode)
    cb('ok')
end)

RegisterNetEvent('br:client:updateQueue')
AddEventHandler('br:client:updateQueue', function(data)
    inQueue = true
    queueData = data
    SendNUIMessage({ action = 'updateQueue', data = data })
end)

RegisterNetEvent('br:client:startGame')
AddEventHandler('br:client:startGame', function(spawnData)
    inQueue = false
    SetNuiFocus(false, false)
    TriggerEvent('br:client:enterGame', spawnData)
end)

-- Open the Battle Royale lobby manually with /br
RegisterCommand('br', function()
    TriggerServerEvent('br:server:playerReady')
end, false)

RegisterCommand('battleroyale', function()
    TriggerServerEvent('br:server:playerReady')
end, false)

-- ESC can close the lobby
CreateThread(function()
    while true do
        if inQueue or IsNuiFocused() then
            if IsControlJustReleased(0, 322) then -- ESC
                SetNuiFocus(false, false)
                SendNUIMessage({ action = 'closeLobbyUI' })
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)
