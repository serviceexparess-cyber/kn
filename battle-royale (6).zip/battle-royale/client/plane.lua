-- Plane drop and parachute descent.
--
-- The plane is created LOCALLY and non-networked on each client. Every player
-- sees their own copy, which avoids one client owning an aircraft that carries
-- everyone else - a common source of desync and "plane disappeared" bugs.

local plane = nil
local jumped = false
local planeCam = nil

-- Cinematic external view: the ped is only attached (not seated), so the
-- default gameplay cam would just keep framing the player. This cam instead
-- follows the plane from directly behind and above, sized to the model's own
-- bounding box, so the whole aircraft stays in frame instead of a side view.
local function createPlaneCam()
    if planeCam or not plane or not DoesEntityExist(plane) then return end

    local minDim, maxDim = GetModelDimensions(GetEntityModel(plane))
    local length = math.max(1.0, maxDim.y - minDim.y)
    local height = math.max(1.0, maxDim.z - minDim.z)
    local backDistance = length * 1.6 + 8.0
    local upDistance = height * 1.4 + 5.0

    planeCam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 50.0, false, 0)
    AttachCamToEntity(planeCam, plane, 0.0, -backDistance, upDistance, true)
    PointCamAtEntity(planeCam, plane, 0.0, 0.0, 0.0, true)
    SetCamActive(planeCam, true)
    RenderScriptCams(true, true, 500, true, false)
end

local function destroyPlaneCam()
    if not planeCam then return end
    RenderScriptCams(false, true, 500, true, false)
    DestroyCam(planeCam, false)
    planeCam = nil
end

local function cleanupPlane()
    destroyPlaneCam()
    if plane and DoesEntityExist(plane) then
        DeleteEntity(plane)
    end
    plane = nil
    BR.inPlane = false
end

local function jumpFromPlane(flight)
    if jumped then return end
    jumped = true
    local ped = PlayerPedId()

    destroyPlaneCam()
    DetachEntity(ped, true, true)
    SetEntityCollision(ped, true, true)

    -- Parachute must be in hand BEFORE the fall, otherwise a player can hit the
    -- ground while the native is still resolving.
    GiveWeaponToPed(ped, joaat(Config.PlaneDrop.parachute), 1, false, false)
    SetPlayerParachuteSmokeTrailColor(PlayerId(), 255, 60, 60)

    Wait(50)
    SetPedToRagdoll(ped, 800, 800, 0, false, false, false)
    ClearPedTasks(ped)
    TaskSkyDive(ped, true)

    SendNUIMessage({ action = 'planeState', state = 'falling' })
    cleanupPlane()

    -- Safety net: auto-deploy under the configured altitude so a stuck skydive
    -- animation can never turn into a death on landing.
    CreateThread(function()
        local deployHeight = (flight and flight.autoDeployHeight) or Config.PlaneDrop.autoDeployHeight
        while BR.inGame do
            Wait(100)
            local currentPed = PlayerPedId()
            local state = GetPedParachuteState(currentPed)

            if state == 0 or state == -1 then
                local coords = GetEntityCoords(currentPed)
                local ground, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)
                local height = ground and (coords.z - groundZ) or coords.z

                if IsPedFalling(currentPed) and height < deployHeight then
                    ForcePedToOpenParachute(currentPed)
                end
            end

            -- Landed.
            if not IsPedFalling(currentPed) and not IsPedInParachuteFreeFall(currentPed)
                and GetPedParachuteState(currentPed) <= 0 and IsPedOnFoot(currentPed) then
                SendNUIMessage({ action = 'planeState', state = 'landed' })
                RemoveWeaponFromPed(currentPed, joaat(Config.PlaneDrop.parachute))
                TriggerServerEvent('br:server:playerLanded')
                return
            end
        end
    end)
end

-- Flies the player along the server-provided path and lets them jump.
function BR.StartPlaneDrop(flight)
    if not flight then return end
    jumped = false

    CreateThread(function()
        local ped = PlayerPedId()
        local startPos = flight.startPos
        local endPos = flight.endPos

        local loaded, hash = LoadModel(flight.model or Config.PlaneDrop.model)
        if not loaded then
            -- Model unavailable: fall back to a high-altitude skydive rather than
            -- leaving the player stuck in an empty sky.
            SetEntityCoords(ped, startPos.x, startPos.y, flight.altitude, false, false, false, false)
            Wait(500)
            jumpFromPlane(flight)
            return
        end

        plane = CreateVehicle(hash, startPos.x, startPos.y, startPos.z, 0.0, false, false)
        SetModelAsNoLongerNeeded(hash)
        SetEntityInvincible(plane, true)
        SetEntityCollision(plane, false, false)
        FreezeEntityPosition(plane, true)
        SetVehicleDoorsLocked(plane, 4)

        -- Point the plane down the flight line.
        local heading = GetHeadingFromVector_2d(endPos.x - startPos.x, endPos.y - startPos.y)
        SetEntityHeading(plane, heading)

        -- Attach rather than seat the ped: the cabin of a titan is not a usable
        -- seat for a jump, and attaching keeps the exit clean.
        AttachEntityToEntity(ped, plane, 0, 0.0, -2.0, 1.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
        BR.inPlane = true
        BR.inGame = true

        createPlaneCam()
        SendNUIMessage({ action = 'planeState', state = 'flying' })
        BR.Notify(BRLocale('jump_prompt'))

        local distance = #(vector3(endPos.x, endPos.y, endPos.z) - vector3(startPos.x, startPos.y, startPos.z))
        local speed = flight.speed or Config.PlaneDrop.speed
        local duration = math.max(5.0, distance / math.max(1.0, speed))
        local elapsed = 0.0
        local forcedJump = flight.forcedJumpAfter or Config.PlaneDrop.forcedJumpAfter

        while BR.inPlane and not jumped do
            Wait(0)
            elapsed = elapsed + (GetFrameTime() or 0.016)
            local t = math.min(1.0, elapsed / duration)

            if plane and DoesEntityExist(plane) then
                SetEntityCoordsNoOffset(plane,
                    startPos.x + (endPos.x - startPos.x) * t,
                    startPos.y + (endPos.y - startPos.y) * t,
                    flight.altitude, false, false, false)
            end

            -- Jump, or be pushed out at the end of the line.
            if IsControlJustPressed(0, 22) or elapsed >= forcedJump or t >= 1.0 then
                jumpFromPlane(flight)
                break
            end

            -- Nothing on screen should hint that the player can drive the plane.
            DisableControlAction(0, 75, true)
        end

        -- If the loop exited without jumping (match ended, resource stopped),
        -- never leave the ped attached to a phantom aircraft.
        if not jumped then
            local currentPed = PlayerPedId()
            if IsEntityAttached(currentPed) then DetachEntity(currentPed, true, true) end
            cleanupPlane()
        end
    end)
end

function BR.AbortPlaneDrop()
    local ped = PlayerPedId()
    if IsEntityAttached(ped) then DetachEntity(ped, true, true) end
    cleanupPlane()
    jumped = false
end

AddEventHandler('onClientResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    cleanupPlane()
end)
