-- In-match HUD. The NUI side draws it; this file only feeds it and guards the
-- thread so restarts cannot stack duplicates.

local hudRunning = false

function BR.StartHUD()
    -- Guard flag: without it every startGame spawns another HUD thread and the
    -- timers tick several times per second.
    if hudRunning then return end
    hudRunning = true
    BR.hudActive = true
    SendNUIMessage({ action = 'showHud', value = true })

    CreateThread(function()
        local elapsed = 0
        while BR.inGame do
            Wait(1000)
            elapsed = elapsed + 1
            local ped = PlayerPedId()
            local zone = BR.zone or {}

            local center = zone.center or Config.Map.center
            local coords = GetEntityCoords(ped)
            local distanceToCenter = #(coords - vector3(center.x, center.y, coords.z))
            local distanceToEdge = math.max(0, math.floor((zone.radius or 0) - distanceToCenter))

            SendNUIMessage({
                action = 'updateHud',
                radius = math.floor(zone.radius or 0),
                initialRadius = math.floor(Config.Map.initialRadius),
                distanceToEdge = distanceToEdge,
                inZone = distanceToCenter <= (zone.radius or 0),
                phase = zone.phase or 0,
                totalPhases = zone.totalPhases or #Config.ZonePhases,
                state = zone.state or 'waiting',
                remaining = zone.remaining or 0,
                remainingLabel = BRFormatTime(zone.remaining or 0),
                elapsed = BRFormatTime(elapsed),
                inPlane = BR.inPlane and true or false
            })
        end
        hudRunning = false
        BR.hudActive = false
        SendNUIMessage({ action = 'showHud', value = false })
    end)
end

function BR.StopHUD()
    BR.hudActive = false
    hudRunning = false
    SendNUIMessage({ action = 'showHud', value = false })
end
