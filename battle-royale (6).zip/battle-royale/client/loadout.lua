-- Weapons received from loot, with the player's equipped skin applied.

RegisterNetEvent('br:client:updateOwned', function(owned)
    BR.owned = owned or { owned = {}, equipped = {} }
    SendNUIMessage({ action = 'updateOwned', owned = BR.owned })
end)

-- Applies the equipped skin for this weapon, if the player owns one.
local function applySkin(ped, weaponHash, weaponName)
    local skin = BRGetSkinForWeapon(BR.skins, weaponName)
    if not skin then return end
    if skin.tint then
        SetPedWeaponTintIndex(ped, weaponHash, skin.tint)
    end
    if skin.components then
        for _, component in ipairs(skin.components) do
            local componentHash = joaat(component)
            if HasPedGotWeaponComponent(ped, weaponHash, componentHash) == false then
                GiveWeaponComponentToPed(ped, weaponHash, componentHash)
            end
        end
    end
end

function BR.GiveWeapon(weaponName, ammo)
    local ped = PlayerPedId()
    if not weaponName then return end
    local hash = joaat(weaponName)
    -- Real weapons, not a cosmetic message: this is the native that arms the ped.
    GiveWeaponToPed(ped, hash, ammo or 60, false, false)
    SetCurrentPedWeapon(ped, hash, true)
    applySkin(ped, hash, weaponName)
end

RegisterNetEvent('br:client:receiveLoot', function(payload)
    if not payload then return end
    local ped = PlayerPedId()

    if payload.weapon then
        BR.GiveWeapon(payload.weapon, payload.ammo)
        local label = payload.weapon:gsub('^WEAPON_', ''):gsub('_', ' ')
        BR.Notify(BRLocale('looted_weapon', label))
    end

    if payload.item then
        if payload.item.type == 'armor' then
            SetPedArmour(ped, math.min(100, GetPedArmour(ped) + payload.item.value))
            BR.Notify(BRLocale('looted_armor', payload.item.value))
        elseif payload.item.type == 'health' then
            local maxHealth = GetEntityMaxHealth(ped)
            SetEntityHealth(ped, math.min(maxHealth, GetEntityHealth(ped) + payload.item.value))
            BR.Notify(BRLocale('looted_health', payload.item.value))
        end
    end

    if payload.tier then
        SendNUIMessage({ action = 'lootPopup', tier = payload.tier, weapon = payload.weapon })
    end
end)

-- Starting kit when a match begins: a fallback pistol so nobody spawns unarmed.
function BR.GiveStarterKit()
    local ped = PlayerPedId()
    RemoveAllPedWeapons(ped, true)
    SetPedArmour(ped, 0)
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    GiveWeaponToPed(ped, joaat('WEAPON_UNARMED'), 0, false, true)
end
