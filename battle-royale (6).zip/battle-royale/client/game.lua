-- Match runtime: zone rendering and damage, crate interaction, death reporting.

local zoneBlip, zoneRadiusBlip, nextZoneBlip = nil, nil, nil
local crateBlips = {}
local crateProps = {}
local zoneThread = false
local crateThread = false
local deathThread = false

-- =============================== TEARDOWN =================================

local function clearWorld()
    if zoneBlip then RemoveBlip(zoneBlip) zoneBlip = nil end
    if zoneRadiusBlip then RemoveBlip(zoneRadiusBlip) zoneRadiusBlip = nil end
    if nextZoneBlip then RemoveBlip(nextZoneBlip) nextZoneBlip = nil end
    for _, blip in pairs(crateBlips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
    crateBlips = {}
    for _, prop in pairs(crateProps) do
        if DoesEntityExist(prop) then DeleteEntity(prop) end
    end
    crateProps = {}
end

-- Brings the ped back from an in-match death. Safe to call even when the ped
-- is already alive (e.g. leaving mid-match, never having died).
function BR.RevivePed()
    local ped = PlayerPedId()
    if not IsEntityDead(ped) then return end

    local coords = GetEntityCoords(ped)
    -- The standard resurrection native: clears the death flag and gets the
    -- ped back on its feet at its current position, instead of respawning
    -- somewhere else.
    NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, GetEntityHeading(ped), true, false)
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    SetPedArmour(ped, 0)
    ClearPedBloodDamage(ped)
    ClearPedTasksImmediately(ped)
    RemoveAllPedWeapons(ped, true)
    SetEntityInvincible(ped, false)
    FreezeEntityPosition(ped, false)
end

function BR.ExitGame()
    BR.inGame = false
    BR.inPlane = false
    BR.gameId = nil
    BR.zone = nil
    BR.lootedCrates = {}
    BR.AbortPlaneDrop()
    clearWorld()
    BR.StopHUD()
    BR.RevivePed()
    SetPlayerInvincible(PlayerId(), false)
end

RegisterNetEvent('br:client:forceExit', function()
    BR.ExitGame()
    BR.Notify('Partie terminee.')
end)

-- ============================== MATCH START ===============================

RegisterNetEvent('br:client:startGame', function(data)
    BR.ServerResponded()
    if not data then return end

    -- Closing the menu here is essential: otherwise the panel stays on screen,
    -- with focus, for the whole match.
    BR.SetMenuOpen(false)

    BR.inGame = true
    BR.gameId = data.gameId
    BR.mode = data.mode
    BR.skins = data.skins or {}
    BR.crates = data.crates or {}
    BR.dropsEnabled = data.dropsEnabled ~= false
    BR.lootedCrates = {}
    BR.zone = {
        center = data.center,
        radius = data.radius,
        damage = 0,
        state = 'waiting',
        remaining = 0,
        phase = 0,
        totalPhases = #Config.ZonePhases
    }

    BR.GiveStarterKit()
    SpawnCrates()
    BR.StartHUD()
    SendNUIMessage({
        action = 'matchStart',
        mode = data.mode,
        total = data.totalPlayers
    })

    if data.planeDrop and data.flight then
        BR.StartPlaneDrop(data.flight)
    elseif data.spawn then
        local ped = PlayerPedId()
        SetEntityCoords(ped, data.spawn.x, data.spawn.y, data.spawn.z, false, false, false, false)
        TriggerServerEvent('br:server:playerLanded')
    end

    StartZoneThread()
    StartCrateThread()
    StartDeathWatch()
end)

RegisterNetEvent('br:client:updateAlive', function(data)
    SendNUIMessage({ action = 'updateAlive', alive = data.alive, total = data.total, kills = data.kills })
end)

-- ================================== ZONE ==================================

RegisterNetEvent('br:client:updateZone', function(zone)
    if not BR.inGame or not zone then return end
    BR.zone = zone
    SendNUIMessage({
        action = 'updateZone',
        radius = zone.radius,
        state = zone.state,
        remaining = zone.remaining,
        phase = zone.phase,
        totalPhases = zone.totalPhases
    })

    if zone.state == 'waiting' and zone.remaining == Config.Zone.warnBeforeShrink then
        BR.Notify(BRLocale('zone_warning', zone.remaining))
    end

    DrawZoneBlips(zone)
end)

function DrawZoneBlips(zone)
    local center = zone.center or Config.Map.center

    -- Current safe circle.
    if zone.radius and zone.radius > 1.0 then
        if not zoneRadiusBlip then
            zoneRadiusBlip = AddBlipForRadius(center.x, center.y, center.z, zone.radius)
            SetBlipHighDetail(zoneRadiusBlip, true)
            SetBlipColour(zoneRadiusBlip, 1)
            SetBlipAlpha(zoneRadiusBlip, Config.Zone.blipAlpha)
        else
            -- Radius blips cannot be resized, so replace it.
            RemoveBlip(zoneRadiusBlip)
            zoneRadiusBlip = AddBlipForRadius(center.x, center.y, center.z, zone.radius)
            SetBlipHighDetail(zoneRadiusBlip, true)
            SetBlipColour(zoneRadiusBlip, 1)
            SetBlipAlpha(zoneRadiusBlip, Config.Zone.blipAlpha)
        end
    elseif zoneRadiusBlip then
        RemoveBlip(zoneRadiusBlip)
        zoneRadiusBlip = nil
    end

    -- The next circle, so players know where to run.
    if nextZoneBlip then RemoveBlip(nextZoneBlip) nextZoneBlip = nil end
    if zone.nextCenter and zone.nextRadius and zone.nextRadius > 1.0 then
        nextZoneBlip = AddBlipForRadius(zone.nextCenter.x, zone.nextCenter.y, zone.nextCenter.z, zone.nextRadius)
        SetBlipHighDetail(nextZoneBlip, true)
        SetBlipColour(nextZoneBlip, 2)
        SetBlipAlpha(nextZoneBlip, 90)
    end
end

function StartZoneThread()
    if zoneThread then return end
    zoneThread = true

    CreateThread(function()
        while BR.inGame do
            Wait(1000)
            local zone = BR.zone
            if zone and zone.damage and zone.damage > 0 and not BR.inPlane then
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
                local center = zone.center or Config.Map.center
                local distance = #(coords - vector3(center.x, center.y, coords.z))

                if distance > (zone.radius or 0.0) then
                    local health = GetEntityHealth(ped)
                    -- Clamped at 1: SetEntityHealth with a negative value can
                    -- put the ped in a broken half-dead state.
                    local newHealth = math.max(1, health - zone.damage)
                    if newHealth <= 1 then
                        SetEntityHealth(ped, 0)
                    else
                        SetEntityHealth(ped, newHealth)
                    end
                    SendNUIMessage({ action = 'inGas', value = true })
                    BR.Notify(BRLocale('outside_zone'))
                else
                    SendNUIMessage({ action = 'inGas', value = false })
                end
            end
        end
        zoneThread = false
        SendNUIMessage({ action = 'inGas', value = false })
    end)
end

-- ================================= CRATES =================================

local TIER_BLIP_COLOUR = { Common = 0, Rare = 3, Epic = 27, Legendary = 5 }

function SpawnCrates()
    if not BR.dropsEnabled then return end
    for _, crate in ipairs(BR.crates) do
        local blip = AddBlipForCoord(crate.x, crate.y, crate.z)
        SetBlipSprite(blip, 478)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, TIER_BLIP_COLOUR[crate.tier] or 0)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('Caisse ' .. (crate.tier or ''))
        EndTextCommandSetBlipName(blip)
        crateBlips[crate.id] = blip
    end
end

local crateLooting = {}

function StartCrateThread()
    if crateThread then return end
    crateThread = true

    CreateThread(function()
        while BR.inGame do
            local sleep = 750
            if BR.dropsEnabled and not BR.inPlane then
                local coords = GetEntityCoords(PlayerPedId())
                for _, crate in ipairs(BR.crates) do
                    if not BR.lootedCrates[crate.id] and not crateLooting[crate.id] then
                        local distance = #(coords - vector3(crate.x, crate.y, crate.z))
                        if distance < 20.0 then
                            sleep = 0
                            SpawnCrateProp(crate)
                            DrawText3D(vector3(crate.x, crate.y, crate.z + 1.0),
                                ('[E] Caisse %s'):format(crate.tier or ''))
                            if distance < 2.5 and IsControlJustReleased(0, 38) then
                                LootCrate(crate)
                            end
                        end
                    end
                end
            end
            Wait(sleep)
        end
        crateThread = false
    end)
end

-- Plays a short opening animation before the loot actually lands, instead of
-- handing it over the instant E is pressed.
function LootCrate(crate)
    if crateLooting[crate.id] or BR.lootedCrates[crate.id] then return end
    crateLooting[crate.id] = true

    local ped = PlayerPedId()
    local dict = 'pickup_object'
    RequestAnimDict(dict)
    local waited = 0
    while not HasAnimDictLoaded(dict) and waited < 1000 do
        Wait(50)
        waited = waited + 50
    end
    -- Flags: upper body only (16) + allow player control (32), so a player
    -- getting shot mid-animation can still react instead of being locked.
    TaskPlayAnim(ped, dict, 'pickup_low', 8.0, -8.0, -1, 48, 0, false, false, false)

    CreateThread(function()
        local elapsed = 0
        while elapsed < 1500 do
            -- Bail out if the crate goes out of range or the match ends -
            -- otherwise a dead/moved-away player would still get the loot.
            if not BR.inGame or #(GetEntityCoords(PlayerPedId()) - vector3(crate.x, crate.y, crate.z)) > 4.0 then
                ClearPedTasks(ped)
                crateLooting[crate.id] = nil
                return
            end
            Wait(50)
            elapsed = elapsed + 50
        end

        ClearPedTasks(ped)
        crateLooting[crate.id] = nil
        BR.lootedCrates[crate.id] = true
        TriggerServerEvent('br:server:lootCrate', crate.id)
        if crateBlips[crate.id] then
            RemoveBlip(crateBlips[crate.id])
            crateBlips[crate.id] = nil
        end
    end)
end

-- Drops the crate prop onto the actual terrain instead of trusting the exact
-- z from config: on a fresh coord (e.g. a map switch) the ground collision
-- may not be loaded yet, and PlaceObjectOnGroundProperly can't find anything
-- to land on - the crate then ends up stuck far below the map.
function SpawnCrateProp(crate)
    if crateProps[crate.id] and DoesEntityExist(crateProps[crate.id]) then return end
    local loaded, hash = LoadModel(Config.CrateModel)
    if not loaded then return end

    RequestCollisionAtCoord(crate.x, crate.y, crate.z)
    local waited = 0
    while not HasCollisionLoadedAroundEntity(PlayerPedId()) and waited < 2000 do
        Wait(50)
        waited = waited + 50
    end

    -- Spawn a few metres above the configured height and let the engine drop
    -- it onto whatever terrain is actually there.
    local prop = CreateObject(hash, crate.x, crate.y, crate.z + 5.0, false, false, false)
    local placed = PlaceObjectOnGroundProperly(prop)
    if not placed then
        SetEntityCoords(prop, crate.x, crate.y, crate.z, false, false, false, false)
    end
    FreezeEntityPosition(prop, true)
    SetModelAsNoLongerNeeded(hash)
    crateProps[crate.id] = prop
end

-- ================================= DEATH ==================================

function StartDeathWatch()
    if deathThread then return end
    deathThread = true

    CreateThread(function()
        while BR.inGame do
            Wait(250)
            local ped = PlayerPedId()
            if IsEntityDead(ped) then
                -- Report the killer so the server can credit the kill; the
                -- server still validates that the killer is in this match.
                local killer = GetPedSourceOfDeath(ped)
                local killerServerId = nil
                if killer and killer ~= 0 and killer ~= ped and IsEntityAPed(killer) then
                    local killerPlayer = NetworkGetPlayerIndexFromPed(killer)
                    if killerPlayer and killerPlayer ~= -1 then
                        killerServerId = GetPlayerServerId(killerPlayer)
                    end
                end
                TriggerServerEvent('br:server:playerDied', killerServerId)
                BR.inGame = false
                -- Revive right away instead of waiting on the server round-trip
                -- for br:client:matchEnd: if that event is ever delayed or lost,
                -- the ped would otherwise stay dead on the ground indefinitely.
                BR.RevivePed()
                break
            end
        end
        deathThread = false
    end)
end

-- ================================ MATCH END ===============================

RegisterNetEvent('br:client:matchEnd', function(result)
    BR.ExitGame()
    SendNUIMessage({ action = 'matchEnd', result = result })
    -- The summary screen needs focus so its buttons are clickable.
    BR.SetMenuOpen(true)
    SendNUIMessage({ action = 'showEndScreen' })
    BR.Notify(result.won and BRLocale('victory') or BRLocale('eliminated', result.placement))
end)
