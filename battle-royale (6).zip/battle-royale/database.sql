-- Battle Royale v3 schema. Safe to re-run.

CREATE TABLE IF NOT EXISTS br_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    citizenid VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(64) DEFAULT NULL,
    xp INT NOT NULL DEFAULT 0,
    level INT NOT NULL DEFAULT 1,
    kills INT NOT NULL DEFAULT 0,
    deaths INT NOT NULL DEFAULT 0,
    wins INT NOT NULL DEFAULT 0,
    matches INT NOT NULL DEFAULT 0,
    gold INT NOT NULL DEFAULT 0,
    diamonds INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_kills (kills),
    INDEX idx_wins (wins),
    INDEX idx_xp (xp)
);

-- Owned cosmetics (skins, tags, crates).
CREATE TABLE IF NOT EXISTS br_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    citizenid VARCHAR(64) NOT NULL,
    item_id VARCHAR(64) NOT NULL,
    item_type VARCHAR(32) NOT NULL,
    equipped TINYINT(1) NOT NULL DEFAULT 0,
    acquired_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_owned (citizenid, item_id),
    INDEX idx_owner (citizenid),
    CONSTRAINT fk_inv_player FOREIGN KEY (citizenid)
        REFERENCES br_players (citizenid) ON DELETE CASCADE
);

-- One row per player per finished match.
CREATE TABLE IF NOT EXISTS br_match_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    citizenid VARCHAR(64) NOT NULL,
    mode VARCHAR(16) NOT NULL,
    placement INT NOT NULL,
    total_players INT NOT NULL,
    kills INT NOT NULL DEFAULT 0,
    damage INT NOT NULL DEFAULT 0,
    survived_seconds INT NOT NULL DEFAULT 0,
    won TINYINT(1) NOT NULL DEFAULT 0,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_player_time (citizenid, played_at),
    CONSTRAINT fk_hist_player FOREIGN KEY (citizenid)
        REFERENCES br_players (citizenid) ON DELETE CASCADE
);
